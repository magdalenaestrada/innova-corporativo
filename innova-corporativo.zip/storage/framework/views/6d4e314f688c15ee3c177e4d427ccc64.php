<div class="modal fade text-left" id="ModalRecepcionar<?php echo e($inventarioingreso->id); ?>" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">

      <div class="card-header">
        <div class="row justify-content-between">
          <div class="col-md-6">
            <h6 class="mt-2"><?php echo e(__('RECEPCIONAR ORDEN DE COMPRA')); ?></h6>
          </div>
          <div class="col-md-6 text-right">
            <button type="button" style="font-size: 30px" class="close" data-dismiss="modal" aria-label="Close">
              <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
            </button>
          </div>
        </div>
      </div>

      <div class="card-body">
        <form action="<?php echo e(route('inventarioingresos.updaterecepcionar', $inventarioingreso->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <div class="row">
            <div class="form-group col-md-3 g-3">
              <label class="text-sm"><?php echo e(__('FECHA DE CREACIÓN')); ?></label>
              <input class="form-control form-control-sm" value="<?php echo e($inventarioingreso->created_at); ?>" readonly>
            </div>
            <div class="form-group col-md-3 g-3">
              <label class="text-sm"><?php echo e(__('ESTADO DE LA ORDEN')); ?></label>
              <input class="form-control form-control-sm" value="<?php echo e($inventarioingreso->estado); ?>" readonly>
            </div>
            <div class="form-group col-md-3 g-3">
              <label class="text-sm"><?php echo e(__('CREADOR DE LA ORDEN')); ?></label>
              <input class="form-control form-control-sm" value="<?php echo e($inventarioingreso->usuario_ordencompra); ?>" readonly>
            </div>
            <div class="form-group col-md-3 g-3">
              <label class="text-sm"><?php echo e(__('ORDEN PAGADA POR')); ?></label>
              <input class="form-control form-control-sm" value="<?php echo e($inventarioingreso->usuario_cancelacion); ?>" readonly>
            </div>

            <div class="form-group col-md-12 g-3">
              <label class="text-sm"><?php echo e(__('DESCRIPCIÓN')); ?></label>
              <textarea class="form-control form-control-sm" readonly><?php echo e($inventarioingreso->descripcion ?: 'No hay observación'); ?></textarea>
            </div>

            <?php if($inventarioingreso->productos->count() > 0): ?>
              <table class="table table-responsive table-striped table-hover">
                <thead>
                  <tr class="text-center">
                    <th><?php echo e(__('SELECCIONAR')); ?></th>
                    <th><?php echo e(__('INGRESAR CANTIDAD RECIBIDA')); ?></th>
                    <th><?php echo e(__('PRODUCTO DEL REQUERIMIENTO')); ?></th>
                    <th><?php echo e(__('CANTIDAD')); ?></th>
                    <th><?php echo e(__('CANTIDAD RECIBIDA')); ?></th>
                    <th><?php echo e(__('CANTIDAD POR RECIBIR')); ?></th>
                    <th><?php echo e(__('FECHA DE CREACIÓN')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $inventarioingreso->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $pivotId     = $producto->pivot->id;
                      $por_recibir = $producto->pivot->cantidad - $producto->pivot->cantidad_ingresada;
                    ?>
                    <tr class="text-center">
                      <td>
                        <?php if($por_recibir > 0): ?>
                          <input
                            type="checkbox"
                            class="product-checkbox"
                            name="selected_products[]"
                            value="<?php echo e($pivotId); ?>"
                            data-target="#qty-<?php echo e($pivotId); ?>"
                          >
                        <?php else: ?>
                          COMPLETO
                        <?php endif; ?>
                      </td>

                      <td>
                        <div class="input-fields" id="wrap-<?php echo e($pivotId); ?>" style="display:none;">
                          <input
                            id="qty-<?php echo e($pivotId); ?>"
                            type="number"
                            class="form-control form-control-sm additional-info"
                            name="qty_arrived[<?php echo e($pivotId); ?>]"
                            min="1"
                            max="<?php echo e($por_recibir); ?>"
                            placeholder="0"
                          >
                          <small class="text-muted">Máx: <?php echo e($por_recibir); ?></small>
                        </div>
                      </td>

                      <td class="text-left"><?php echo e($producto->nombre_producto); ?></td>
                      <td><?php echo e($producto->pivot->cantidad); ?></td>
                      <td><?php echo e($producto->pivot->cantidad_ingresada); ?></td>
                      <td><?php echo e($por_recibir); ?></td>
                      <td><?php echo e($producto->pivot->created_at); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <?php endif; ?>

            <div class="form-group col-md-4 g-3 text-sm">
              <label for="guiaingresoalmacen"><?php echo e(__('GUIA DE INGRESO AL ALMACEN')); ?></label>
             
              <input class="form-control form-control-sm"  type="text" name="guiaingresoalmacen">
            </div>

            <div class="col-md-12 text-right g-3">
              <button type="submit" class="btn btn-sm btn-warning">
                <?php echo e(__('CONFIRMAR INGRESO DE LOS PRODUCTOS AL ALMACEN')); ?>

              </button>
            </div>
          </div>
        </form>
      </div>

    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.product-checkbox').forEach(function(chk) {
    chk.addEventListener('change', function() {
      const input = document.querySelector(this.dataset.target);
      const id    = this.dataset.target.replace('#qty-', '');
      const wrap  = document.querySelector('#wrap-' + id);

      if (this.checked) {
        wrap.style.display = 'block';
        input.required = true;
        input.focus();
      } else {
        wrap.style.display = 'none';
        input.required = false;
        input.value = '';
      }
    });
  });
});
</script>
<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/inventarioingresos/modal/recepcionar.blade.php ENDPATH**/ ?>