

<?php $__env->startSection('content'); ?>
<br>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('CREAR TICKET DE COMEDOR')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('ranchos.index')); ?>">
                            <?php echo e(__('VOLVER')); ?>

                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form class="crear-rancho" action="<?php echo e(route('ranchos.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>


                    <div class="row">




                        
                        <div class="form-group col-md-12 g-3">
                            <label for="datos_cliente" class="text-muted">
                                <?php echo e(__('NOMBRE CLIENTE')); ?>

                            </label>
                            <div class="input-field">
                                <input type="text" name="datos_cliente" id="datos_cliente"
                                    class="form-control <?php $__errorArgs = ['datos_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Datos obtenidos automáticamente...">
                            </div>

                            <?php $__errorArgs = ['datos_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        

                        <div class="form-group col-md-4 g-3">
                            <label for="documento_trabajador" class="text-success">
                                <?php echo e(__('DOCUMENTO COMENSAL')); ?>

                            </label>
                            <div class="input-group">
                                <input type="text" name="documento_trabajador" id="documento_trabajador"
                                    class="form-control <?php $__errorArgs = ['documento_trabajador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('documento_trabajador')); ?>" placeholder="INGRESE DNI O RUC">
                                <button class="btn btn-primary" type="button" id="buscar_trabajador_btn">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                        viewBox="0 0 25 25" style="fill: rgba(255, 255, 255, 1);transform: ;msFilter:;">
                                        <path
                                            d="M19.023 16.977a35.13 35.13 0 0 1-1.367-1.384c-.372-.378-.596-.653-.596-.653l-2.8-1.337A6.962 6.962 0 0 0 16 9c0-3.859-3.14-7-7-7S2 5.141 2 9s3.14 7 7 7c1.763 0 3.37-.66 4.603-1.739l1.337 2.8s.275.224.653.596c.387.363.896.854 1.384 1.367l1.358 1.392.604.646 2.121-2.121-.646-.604c-.379-.372-.885-.866-1.391-1.36zM9 14c-2.757 0-5-2.243-5-5s2.243-5 5-5 5 2.243 5 5-2.243 5-5 5z">
                                        </path>
                                    </svg>
                                </button>
                            </div>
                            <?php $__errorArgs = ['documento_trabajador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-8 g-3">
                            <label for="datos_trabajador" class="text-muted">
                                <?php echo e(__('DATOS COMENSAL')); ?>

                            </label>
                            <div class="input-field">

                                <input type="text" name="datos_trabajador" id="datos_trabajador"
                                    class="form-control <?php $__errorArgs = ['datos_trabajador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('datos_trabajador')); ?>"
                                    placeholder="Datos obtenidos automáticamente...">
                            </div>
                            <?php $__errorArgs = ['datos_trabajador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        <div class="form-group col-md-3 g-3 ">
                            <label for="lote" class="text-muted">
                                <?php echo e(__('LOTE')); ?>

                            </label>
                            <div class="input-field">

                                <input type="text" name="lote" id="lote"
                                    class="form-control <?php $__errorArgs = ['lote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('lote')); ?>"
                                    placeholder="Ingresar lote...">
                            </div>
                            <?php $__errorArgs = ['lote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        

                        

                        <div class="form-group col-md-3 g-3">
                            <label for="cantidad" class="text-muted">
                                <?php echo e(__('CANTIDAD')); ?>

                            </label>
                            <input type="number" name="cantidad" id="cantidad"
                                class="form-control <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('cantidad')); ?>" placeholder="0" min="0">
                            <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group col-md-6 g-3">
                            <label for="comida" >
                                <?php echo e(__('COMIDA')); ?>

                            </label>
                            <br>
                            <select name="comida_id" id="comida"
                                class="form-control  buscador <?php $__errorArgs = ['sociedad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                aria-label="" style="width: 100%" required>
                                <option selected value="">
                                    SELECCIONE LA COMIDA
                                </option>
                                <?php $__currentLoopData = $comidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($comida->id); ?>"
                                        <?php echo e(old('comida') == $comida->id ? 'selected' : ''); ?>>
                                        <?php echo e(strtoupper($comida->nombre)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['comida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                      
                      



                        <div class="col-md-12 text-right g-3">
                            <button type="submit" class="btn btn-secondary btn-sm">
                                <?php echo e(__('GUARDAR TICKET DE COMEDOR')); ?>

                            </button>
                        </div>

                    </div>
            </div>
            </form>
        </div>
    </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script type="text/javascript">
            $(document).ready(function() {

                $.ajax({
                    type: 'get',
                    url: '<?php echo e(route('findPersona')); ?>',
                    success: function(response) {
                        console.log(response);

                        var custArray = response;
                        var dataCust = {};
                        var dataCust2 = {};
                        for (var i = 0; i < custArray.length; i++) {
                            dataCust[custArray[i].datos_persona] = null;
                            dataCust2[custArray[i].datos_persona] = custArray[i];
                        }
                        console.log("dataCust2");
                        console.log(dataCust2);


                        $('input#datos_cliente').autocomplete({
                            data: dataCust,
                            onAutocomplete: function(reqdata) {

                                $('#documento_cliente').val(dataCust2[reqdata][
                                    'documento_persona'
                                ]);
                            }
                        })
                    }
                })

                $.ajax({
                    type: 'get',
                    url: '<?php echo e(route('findPersona')); ?>',
                    success: function(response) {
                        console.log(response);

                        var custArray = response;
                        var dataCust = {};
                        var dataCust2 = {};
                        for (var i = 0; i < custArray.length; i++) {
                            dataCust[custArray[i].datos_persona] = null;
                            dataCust2[custArray[i].datos_persona] = custArray[i];
                        }
                        console.log("dataCust1");
                        console.log(dataCust2);


                        $('input#datos_socio').autocomplete({
                            data: dataCust,
                            onAutocomplete: function(reqdata) {

                                $('#documento_socio').val(dataCust2[reqdata][
                                    'documento_persona']);
                            }
                        })
                    }
                })

                $.ajax({
                    type: 'get',
                    url: '<?php echo e(route('findPersona')); ?>',
                    success: function(response) {
                        console.log(response);

                        var custArray = response;
                        var dataCust = {};
                        var dataCust2 = {};
                        for (var i = 0; i < custArray.length; i++) {
                            dataCust[custArray[i].datos_persona] = null;
                            dataCust2[custArray[i].datos_persona] = custArray[i];
                        }
                        console.log(dataCust2);


                        $('input#datos_trabajador').autocomplete({
                            data: dataCust,
                            onAutocomplete: function(reqdata) {

                                $('#documento_trabajador').val(dataCust2[reqdata][
                                    'documento_persona'
                                ]);
                            }
                        })
                    }
                })


            })
        </script>
        <script>
            $('.crear-cliente').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: '¿Crear cliente?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Si, confirmar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/ranchos/create.blade.php ENDPATH**/ ?>