
<?php $__env->startPush('css'); ?>
   <link rel="stylesheet" href="<?php echo e(asset('css/areas.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <br>
        <div class="row d-flex justify-content-between align-items-center">
            <div class="loader">
                <?php echo e(__('CLIENTES REGISTRADOS')); ?>

            </div>    
            <div class="text-right col-md-6">
                <a class="" href="#" data-toggle="modal" data-target="#ModalCreate">
                    <button class="button-create">
                        <?php echo e(__('REGISTRAR CLIENTE')); ?>

                    </button>
                </a>
            </div>
        </div>
    
        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table id="products-table" class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">
                                        <?php echo e(__('DOCUMENTO')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('NOMBRE')); ?>

                                    </th>
                                </tr>
                            </thead>

                            <tbody style="font-size: 13px">
                                <?php if(count($clientes) > 0): ?>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row">
                                                <?php echo e(strtoupper($cliente->documento)); ?> 
                                            </td>

                                            <td scope="row">
                                                <?php echo e(strtoupper($cliente->nombre)); ?> 
                                            </td>


                                            
                                            

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">
                                            <?php echo e(__('NO HAY DATOS DISPONIBLES')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>    
                         <!-- Pagination Links -->
                            <div class="d-flex justify-content-between">
                                <div>
                                    <?php echo e($clientes->links('pagination::bootstrap-4')); ?>

                                </div>
                                <div>
                                    <?php echo e(__('MOSTRANDO DEL')); ?> <?php echo e($clientes->firstItem()); ?> <?php echo e(__('AL')); ?> <?php echo e($clientes->lastItem()); ?> <?php echo e(__('DE')); ?> <?php echo e($clientes->total()); ?> <?php echo e(__('REGISTROS')); ?>

                                </div>
                            </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('liquidaciones.clientes.modal.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('js/updateadvice.js')); ?>"></script>

<script>
    <?php if(session('status')): ?>
    Swal.fire('ÉXITO', '<?php echo e(session('status')); ?>', 'success');
    <?php elseif(session('error')): ?>
    Swal.fire('ERROR', '<?php echo e(session('error')); ?>', 'error');
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/liquidaciones/clientes/index.blade.php ENDPATH**/ ?>