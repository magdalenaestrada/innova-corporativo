<div class="modal fade text-left" id="ModalShow<?php echo e($nota->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered custom-modal-width" role="document">
        <div class="modal-content">

            
            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('NOTAS DE PEDIDO')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal"
                            aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                        </button>
                    </div>
                </div>
            </div>

            
            <div class="card-body">
                <div class="form-group">
                    <div class="row">
                        <div class="form-group col-md-2 g-3">
                            <label class="text-sm"><?php echo e(__('CÓDIGO')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->codigo); ?>" disabled>
                        </div>

                        <div class="form-group col-md-2 g-3">
                            <label class="text-sm"><?php echo e(__('FECHA DE CREACIÓN')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->fecha_creacion); ?>" disabled>
                        </div>

                        <div class="form-group col-md-3 g-3">
                            <label class="text-sm"><?php echo e(__('DNI')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->dni); ?>" disabled>
                        </div>

                        <div class="form-group col-md-5 g-3">
                            <label class="text-sm"><?php echo e(__('CONDUCTOR')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->conductor); ?>"
                                disabled>
                        </div>

                    </div>
                    
                    <div class="row">
                        <div class="form-group col-md-2 g-3">
                            <label class="text-sm"><?php echo e(__('TELEFONO')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->telefono); ?>" disabled>
                        </div>

                        <div class="form-group col-md-2 g-3">
                            <label class="text-sm"><?php echo e(__('PLACA')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->placa_vehiculo); ?>" disabled>
                        </div>

                        <div class="form-group col-md-2 g-3">
                            <label class="text-sm"><?php echo e(__('KILOMETRAJE')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->kilometraje); ?>" disabled>
                        </div>

                        <div class="form-group col-md-6 g-3">
                            <label class="text-sm"><?php echo e(__('ENCARGADO')); ?></label>
                            <input class="form-control form-control-sm" value="<?php echo e($nota->encargado->nombre); ?>"
                                disabled>
                        </div>

                    </div>

                    
                    <div class="form-group col-md-12 g-3">
                        <label class="text-sm"><?php echo e(__('DESCRIPCIÓN / OBSERVACIÓN')); ?></label>
                        <textarea class="form-control form-control-sm" rows="3" disabled><?php echo e($nota->descripcion ?? 'Sin descripción registrada'); ?></textarea>
                    </div>

                    
                    <div class="mt-3 table-responsive">
                        <?php if($nota->detalles && $nota->detalles->count() > 0): ?>
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr class="text-center" style="font-size: 14px">
                                        <th><?php echo e(__('PRODUCTO')); ?></th>
                                        <th><?php echo e(__('CANTIDAD')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $nota->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center" style="font-size: 13px">
                                            <td><?php echo e($detalle->producto->nombre_producto); ?></td>
                                            <td><?php echo e($detalle->cantidad); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p class="text-center mt-3">No hay detalles de servicio registrados.</p>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/notas/modal/show.blade.php ENDPATH**/ ?>