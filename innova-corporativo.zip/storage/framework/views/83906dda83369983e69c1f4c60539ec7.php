<div class="modal fade text-left" id="ModalShow<?php echo e($inventarioingreso->id); ?>" tabindex="-1" role="dialog"
    aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered custom-modal-width" role="document">
        <div class="modal-content">


            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('ORDEN DE COMPRA')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal"
                            aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-body">

                <div class="form-group">

                    <div class="row">
                        <div class="form-group col-md-4 g-3">
                            <label for="fecha" class="text-sm">
                                <?php echo e(__('FECHA DE CREACIÓN')); ?>

                            </label>
                            <input class="form-control form-control-sm" value="<?php echo e($inventarioingreso->created_at); ?>"
                                disabled>
                        </div>

                        <div class="form-group col-md-4 g-3">
                            <label for="estado" class="text-sm"class="text-sm">
                                <?php echo e(__('ESTADO DE LA ORDEN')); ?>

                            </label>
                            <input class="form-control form-control-sm" value="<?php echo e($inventarioingreso->estado); ?>"
                                disabled>
                        </div>

                        <div class="form-group col-md-4 g-3">
                            <label for="creador" class="text-sm">
                                <?php echo e(__('CREADOR DE LA ORDEN')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($inventarioingreso->usuario_ordencompra); ?>" disabled>
                        </div>

                        <div class="form-group col-md-4 g-3">
                            <label for="inventarioingreso_fin" class="text-sm">
                                <?php echo e(__('ORDEN PAGADA POR')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($inventarioingreso->usuario_cancelacion); ?>" disabled>
                        </div>

                        <div class="form-group col-md-4 g-3">
                            <label for="inventarioingreso_fin" class="text-sm">
                                <?php echo e(__('ORDEN RECEPCIONADA POR')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($inventarioingreso->usuario_recepcionista); ?>" disabled>
                        </div>
                         <div class="form-group col-md-4 g-3">
                            <label for="cotizacion" class="text-sm">
                                <?php echo e(__('CODIGO COTIZACION')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($inventarioingreso->cotizacion); ?>" disabled>
                        </div>
                    </div>

                    <?php if($inventarioingreso->proveedor): ?>
                        <div class="row mb-3">

                            <div class="form-group col-md-4 g-3">
                                <label for="documento_proveedor" class="text-sm">
                                    <?php echo e(__('RUC PROVEEDOR')); ?>

                                </label>
                                <div class="input-group">
                                    <input class="form-control form-control-sm"
                                        value="<?php echo e($inventarioingreso->proveedor->ruc); ?>" disabled>

                                </div>
                            </div>
                            <div class="form-group col-md-8 g-3">
                                <label for="datos_proveedor" class="text-sm">
                                    <?php echo e(__('RAZÓN SOCIAL PROVEEDOR')); ?>

                                </label>
                                <input class="form-control form-control-sm"
                                    value="<?php echo e($inventarioingreso->proveedor->razon_social); ?>" disabled>
                            </div>


                            <div class="form-group col-md-12 g-3" >
                                <label for="descripcion" class="text-sm">
                                    <?php echo e(__('OBSERVACIÓN')); ?>

                                </label>
                                <textarea class="form-control form-control-sm" disabled><?php echo e($inventarioingreso->descripcion ? $inventarioingreso->descripcion : 'No hay observación'); ?></textarea>
                            </div>
                            

                        </div>
                    <?php endif; ?>



                    



                    <div class="mt-2 table-responsive">
                        <?php if(count($inventarioingreso->productos) > 0): ?>
                            <table class="table  table-striped table-hover">
                                <thead>
                                    <tr class="text-center" style="font-size: 14px">

                                        <th scope="col">
                                            <?php echo e(__('PRODUCTO DEL REQUERIMIENTO')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('CANTIDAD')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('UNIDAD')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('PRECIO UNITARIO')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('SUBTOTAL')); ?>

                                        </th>


                                        <th scope="col">
                                            <?php echo e(__('GUIA DE INGRESO AL ALMACEN')); ?>

                                        </th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $inventarioingreso->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center" style="font-size: 12.5px">
                                            <td scope="row">
                                                <?php echo e($producto->nombre_producto); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($producto->pivot->cantidad); ?>

                                            </td>

                                            <td>
                                                <?php if($producto->unidad): ?>
                                                    <?php echo e($producto->unidad->nombre); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td scope="row">
                                                <?php echo e($producto->pivot->precio); ?>

                                            </td>
                                            <td scope="row" class="text-right">
                                                <?php echo e($producto->pivot->subtotal); ?>

                                            </td>


                                            <td scope="row">
                                                <?php echo e($producto->pivot->guiaingresoalmacen); ?>

                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <tr class="table-warning">
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>SUMA: </td>

                                        <td class="text-end">
                                            <div class="text-right">
                                                <?php echo e($inventarioingreso->suma>0 ? number_format($inventarioingreso->suma, 2) : number_format($inventarioingreso->subtotal, 2)); ?></div>
                                        </td>
                                        <td></td>
                                    </tr>
                                </tbody>



                            </table>
                        <?php endif; ?>
                    </div>

                    <p class="text-center h6 mb-3"> DESCUENTO: <?php echo e(number_format($inventarioingreso->descuento, 2)); ?>

                        </p>

                    <p class="text-center h6 mb-3"> SUBTOTAL: <?php echo e(number_format($inventarioingreso->subtotal, 2)); ?>

                       </p>
                    <p class="text-center h4 mb-3"> COSTO TOTAL: <?php echo e(number_format($inventarioingreso->total, 2)); ?>

                        <?php echo e($inventarioingreso->tipomoneda); ?></p>


                    <div class="row">





                        <div class="form-group col-md-4 g-3">
                            <label for="tipocomprobante" class="text-sm">
                                <?php echo e(__('COMPROBANTE')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($inventarioingreso->tipocomprobante); ?>" disabled>
                        </div>

                        <div class="form-group col-md-4 g-3">
                            <label for="comprobante_correlativo" class="text-sm">
                                <?php echo e(__('CORRELATIVO')); ?>

                            </label>
                            <input class="form-control form-control-sm" type="text"
                                value="<?php echo e($inventarioingreso->comprobante_correlativo); ?>" disabled>
                        </div>



                        <div class="form-group col-md-4 g-3">
                            <label for="fecha_emision_comprobante" class="text-sm">
                                <?php echo e(__('FECHA EMISIÓN')); ?>

                            </label>
                            <input class="form-control form-control-sm" type="text"
                                value="<?php echo e($inventarioingreso->fecha_emision_comprobante); ?>" disabled>
                        </div>





                        <div class="form-group col-md-3 g-3">
                            <label for="estado_pago" class="text-sm">
                                <?php echo e(__('ESTADO PAGO')); ?>

                            </label>
                            <input class="form-control form-control-sm" type="text"
                                value="<?php echo e($inventarioingreso->estado_pago); ?>" disabled>
                        </div>


                        <div class="form-group col-md-3 g-3">
                            <label for="fecha_cancelacion" class="text-sm">
                                <?php echo e(__('FECHA DE CANCELACIÓN')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($inventarioingreso->fecha_cancelacion); ?>" disabled>
                        </div>

                        <div class="form-group col-md-3 g-3">
                            <label for="tipopago" class="text-sm">
                                <?php echo e(__('TIPO PAGO')); ?>

                            </label>
                            <input class="form-control form-control-sm" type="text"
                                value="<?php echo e($inventarioingreso->tipopago); ?>" disabled>
                        </div>


                        <?php if($inventarioingreso->tipomoneda == 'DOLARES'): ?>
                            <div class="form-group col-md-3 g-3">
                                <label for="cambio_dia" class="text-sm">
                                    <?php echo e(__('CAMBIO DEL DÍA')); ?>

                                </label>
                                <input class="form-control form-control-sm" type="text"
                                    value="<?php echo e(number_format($inventarioingreso->cambio_dolar_precio_venta, 2)); ?>"
                                    disabled>
                            </div>
                        <?php endif; ?>



                        <div class="mt-2 table-responsive">
                            <?php if(count($inventarioingreso->pagosacuenta) > 0): ?>
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr class="text-center">
                                            <th scope="col">
                                                <?php echo e(__('FECHA DE PAGO O ADELANTO A CUENTA')); ?>

                                            </th>
                                            <th scope="col">
                                                <?php echo e(__('MONTO')); ?>

                                            </th>
                                            <th scope="col">
                                                <?php echo e(__('COMPROBANTE CORRELATIVO')); ?>

                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $inventarioingreso->pagosacuenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center">
                                                <td scope="row">
                                                    <?php echo e($pago->fecha_pago); ?>

                                                </td>
                                                <td scope="row">
                                                    <?php echo e($pago->monto); ?>

                                                </td>
                                                <td scope="row">
                                                    <?php echo e($pago->comprobante_correlativo); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/inventarioingresos/modal/show.blade.php ENDPATH**/ ?>