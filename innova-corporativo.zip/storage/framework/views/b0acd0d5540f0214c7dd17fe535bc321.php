

<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                            <div class="col-md-6">
                            <?php echo e(__('TODAS LAS OPERACIONES REGISTRADAS')); ?>

                            </div>
                            <div class="col-md-6 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear registro')): ?>
                                    <a class="btn btn-sm btn-special" href="<?php echo e(route('registros.create')); ?>">
                                    <?php echo e(__('CREAR NUEVO REGISTRO')); ?>

                                </a>
                            <?php endif; ?>
                            </div>
                        
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-hover">
                            <?php if(count($registros) > 0): ?>
                            <thead>
                                <tr>
                                    <th scope="col">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('Operación')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('Fecha y hora de registro')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('Tipo de Vehículo')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('Placa')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('Documento cliente')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('Nombre o Razón Social Cliente')); ?>

                                    </th>
                    
                                    <th>
                                        <?php echo e(__('Acción')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row">
                                            <?php echo e($registro->id); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($registro->accion->nombre_accion); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e(($registro->created_at)->format('d/m/Y - H:i:s')); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($registro->tipoVehiculo->nombre_vehiculo); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($registro->placa); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($registro->documento_cliente); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($registro->datos_cliente); ?>

                                        </td>
                                        
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver registro')): ?>
                                            <a href="<?php echo e(route('registros.show', $registro->id)); ?>" class="btn btn-secondary btn-sm">
                                                <?php echo e(__('VER')); ?>

                                            </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar registro')): ?>
                                            <a href="<?php echo e(route('registros.edit', $registro->id)); ?>" class="btn btn-warning btn-sm">
                                                <?php echo e(__('EDITAR')); ?>

                                            </a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar registro')): ?>
                                            <form class="eliminar-registro" action="<?php echo e(route('registros.destroy', $registro->id)); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <?php echo e(__('ELIMINAR')); ?>

                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted">
                                        <?php echo e(__('No hay datos disponibles')); ?> 
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end">
                                <li class="page-item <?php echo e($registros->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($registros->previousPageUrl()); ?>">
                                        <?php echo e(__('Anterior')); ?>

                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $registros->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($registros->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($registros->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo e($registros->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link" href="<?php echo e($registros->nextPageUrl()); ?>">
                                        <?php echo e(__('Siguiente')); ?>

                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('js/updateadvice.js')); ?>"></script>

        <script>
            <?php if(session('eliminar-registro') == 'Registro eliminado con éxito.'): ?>
                Swal.fire('Registro', 'eliminado exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('crear-registro') == 'Registro creado con éxito.'): ?>
                Swal.fire('Registro', 'creado exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('editar-registro') == 'Registro actualizado con éxito.'): ?>
                Swal.fire('Registro', 'actualizado exitosamente.', 'success')
            <?php endif; ?>
        </script>
        <script>
            $('.eliminar-registro').submit(function(e){
                e.preventDefault();
                Swal.fire({
                    title: '¿Eliminar registro?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, continuar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        this.submit();
                    }
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/registros/index.blade.php ENDPATH**/ ?>