

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="col-md-6">
                        <?php echo e(__('TODOS LOS PAGOS DEL COMEDOR REGISTRADOS')); ?>

                        </div>
                        <div class="col-md-6 text-right">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('use pagos tickets comedor')): ?>
                            <a class="btn btn-sm btn-special" href="<?php echo e(route('abonados.create')); ?>">
                                <?php echo e(__('PAGAR TICKETS DEL COMEDOR')); ?>

                            </a>
                        <?php endif; ?>
                        </div>
                           
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-hover" >
                            <?php if(count($abonados) > 0): ?>
                            <thead>
                                <tr>

                                    <th scope="col">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('FECHA CANCELACIÓN')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('FECHA CREACIÓN')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('CLIENTE')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('USUARIO')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('ACCIÓN')); ?>

                                    </th>
                                </tr>
                            </thead>
                            <tbody style="font-size: 13px">
                                <?php $__currentLoopData = $abonados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abonado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row">
                                            <?php echo e($abonado->id); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($abonado->fecha_cancelacion); ?>

                                        </td>
                                        <td scope="row">
                                            <?php echo e($abonado->created_at); ?>

                                        </td> 
                                        
                                        <td scope="row">
                                            <?php
                                            $reg_ranchos= $abonado->ranchos;
                                            $doc = '';
                                            foreach ( $reg_ranchos as $rancho)
                                            {
                                                $doc = $rancho->datos_cliente;
                                            }
                                            ?>    
                                            <?php echo e($doc); ?>                                           
                                        </td>
                                        <td scope="row">
                                            <?php echo e($abonado->usuario); ?>

                                        </td> 
                                        
                                        
                                        <td>                      
                                            <a href="<?php echo e(route('abonados.show', $abonado->id)); ?>" class="btn btn-secondary btn-sm">
                                                <?php echo e(__('VER')); ?>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted">
                                        <?php echo e(__('No hay datos disponibles')); ?> 
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end">
                                <li class="page-item <?php echo e($abonados->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($abonados->previousPageUrl()); ?>">
                                        <?php echo e(__('Anterior')); ?>

                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $abonados->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($abonados->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($abonados->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo e($abonados->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link" href="<?php echo e($abonados->nextPageUrl()); ?>">
                                        <?php echo e(__('Siguiente')); ?>

                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="<?php echo e(asset('js/updateadvice.js')); ?>"></script>
        <script type="text/javascript">
            $(document).ready(function(){
            $('.btnprn').printPage();
            
            });
        </script>

    
        <script>
            <?php if(session('crear-abonado-cancelar-tickets') == 'Se cancelaron los tickets de comedor exitosamente.'): ?>
                Swal.fire('Liquidación de comedor', 'realizada exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('crear-registro') == 'Registro creado con éxito.'): ?>
                Swal.fire('Registro', 'creado exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('editar-registro') == 'Registro actualizado con éxito.'): ?>
                Swal.fire('Registro', 'actualizado exitosamente.', 'success')
            <?php endif; ?>
        </script>
        <script>
            $('.eliminar-registro').submit(function(e){
                e.preventDefault();
                Swal.fire({
                    title: '¿Eliminar registro?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, continuar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        this.submit();
                    }
                })
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/abonados/index.blade.php ENDPATH**/ ?>