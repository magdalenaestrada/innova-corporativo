<div class="modal fade text-left" id="ModalEditar<?php echo e($producto->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
           

            <div class="card-header row justify-content-between align-items-center">
                        <div class="col-md-6">
                            <h6 class="mt-2">
                                <?php echo e(__('MÓDULO PARA EDITAR PRODUCTOS')); ?>

                            </h6>
                        </div>
                        <div class="col-md-6 text-right">
                            <button type="button" style="font-size: 30px" class="close" data-dismiss="modal" aria-label="Close">
                                <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                            </button>
                        </div>
            </div>
        
            <div class="card-body">
                    <form class="editar-producto" action="<?php echo e(route('productos.update', ['producto' => $producto->id, 'page' => request()->page])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">

                            <div class="form-group col-md-12 g-3">
                                <label for="nombre_producto" class="text-sm">
                                    <?php echo e(__('NOMBRE DEL PRODUCTO')); ?>

                                </label>
                                <input type="text" value="<?php echo e($producto->nombre_producto); ?>" name="nombre_producto" id="nombre_producto" class="form-control form-control-sm <?php $__errorArgs = ['nombre_producto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombre_producto')); ?>" placeholder="Ingrese un nombre para este producto">
                                <?php $__errorArgs = ['nombre_producto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-12 g-3">
                                    <label for="productosfamilia_id" class="text-sm">
                                        <b>
                                            <?php echo e(__('FAMILIA')); ?>

                                        </b>
                                    </label>
                                    <select name="productosfamilia_id" id="productosfamilia_id"
                                        class="form-control form-control-sm <?php $__errorArgs = ['productosfamilia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Productos Familia">
                                        <option selected disabled><?php echo e(__('-- Seleccione una opción')); ?></option>

                                        <?php $__currentLoopData = $productosfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($familia->id); ?>"
                                                <?php echo e(old('productosfamilia_id', isset($producto) ? $producto->productosfamilia_id : '') == $familia->id ? 'selected' : ''); ?>>
                                                <?php echo e($familia->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <div class="form-group mt-4 g-3">
                                        <label for="unidad_id" class="text-muted">
                                            <?php echo e(__('UNIDADES')); ?>

                                        </label>
                                        <select name="unidad_id" id="unidad_id" class="form-control form-control-sm <?php $__errorArgs = ['unidad_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Unidad">
                                            <?php if(old('unidad_id')): ?>
                                                <!-- If there's an old value (after validation error), pre-select the old value -->
                                                <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($unidad->id); ?>" <?php echo e(old('unidad_id') == $unidad->id ? 'selected' : ''); ?>>
                                                        <?php echo e($unidad->nombre); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <!-- Pre-select product's unidad if editing -->
                                                <?php if(!empty($producto->unidad_id)): ?>
                                                    <option selected value="<?php echo e($producto->unidad_id); ?>">
                                                        <?php echo e($producto->unidad_nombre); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option selected disabled><?php echo e(__('-- Seleccione una opción')); ?></option>
                                                <?php endif; ?>
                                        
                                                <!-- Other unidades for selection -->
                                                <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($unidad->id); ?>">
                                                        <?php echo e($unidad->nombre); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        
                                    </div>
                                    
                                        <?php $__errorArgs = ['unidad_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <?php if($producto->precio==0): ?>
                                    <div class="form-group col-md-12 g-3">
                                        <label for="valor_promedio" class="text-muted">
                                            <?php echo e(__('VALOR PROMEDIO')); ?>

                                        </label>
                                        <input type="text" name="valor_promedio" id="valor_promedio" class="form-control <?php $__errorArgs = ['valor_promedio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('valor_promedio')); ?>" placeholder="Ingrese  el valor promedio de este producto">
                                        <?php $__errorArgs = ['valor_promedio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>


                                    <?php $__errorArgs = ['estado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                            </div>


                            <div class="col-md-12 text-right mt-2 g-3">
                                <button type="submit" class="btn btn-secondary btn-sm">
                                    <?php echo e(__('ACTUALIZAR PRODUCTO')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
            </div>
          
            
    
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/productos/modal/edit.blade.php ENDPATH**/ ?>