<div class="modal fade text-left" id="ModalExport"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('REPORTE')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal" aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form class="crear-accion" action="<?php echo e(route('pesos.export-excel')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="form-group col-md-12 g-3">
                            <label for="observacion" class="text-muted">
                                <?php echo e(__('OBSERVACIÓN')); ?>

                            </label>
                            <br>
                            <select name="Observacion" id="Observacion" class=" form-control buscador <?php $__errorArgs = ['Observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%">
                                <option selected disabled>
                                    Seleccione uno de las Observaciones listados
                                </option>
                                <?php
                                    $observedPesos = [];
                                ?>
                                <?php $__currentLoopData = $pesos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!in_array($peso->Observacion, $observedPesos)): ?>
                                        <option value="<?php echo e($peso->Observacion); ?>" <?php echo e(old('peso') == $peso->Observacion ? 'selected' : ''); ?>>
                                            <?php echo e($peso->Observacion); ?>

                                        </option>
                                        <?php
                                            $observedPesos[] = $peso->Observacion;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                      



                        <div class="form-group col-md-6 g-3">
                            <label for="start_date" class="text-muted">
                                <?php echo e(__('FECHA INICIAL')); ?>

                            </label>
                            <input type="datetime-local" name="start_date" placeholder="Ingrese la fecha Inicial"
                                class="form-control">
                        </div>

                        <div class="form-group col-md-6 g-3">
                            <label for="end_date" class="text-muted">
                                <?php echo e(__('FECHA FINAL')); ?>

                            </label>
                            <input type="datetime-local" name="end_date" placeholder="Ingrese la fecha Final"
                                class="form-control">
                        </div>

                        

                        
                       
                        
                       

                      
                        <div class="col-md-12 text-right g-3">
                            <button type="submit" class="btn btn-secondary btn-sm">
                                <?php echo e(__('EXPORTAR REPORTE')); ?>

                            </button>   
                        </div>
                    </div>
                </form>
            </div>
        
        </div>
    </div>
</div>
<?php $__env->startPush('js'); ?>
<script>
            $('.crear-producto').submit(function(e){
                e.preventDefault();
                Swal.fire({
                    title: '¿Crear producto?',
                    icon: 'warning',
                    ShowCancelButton: true,
                    ConfirmButtonColor: '#3085d6',
                    CancelButtonColor: '#d33',
                    ConfirmButtonText: '¡Si, confirmar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        this.submit();
                    }
                })
            });
</script>


<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    
    
    $(document).ready(function() {
        $('.buscador').select2({theme: "classic"});
    });
</script>

<?php if($errors->any()): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error de validación',
                    html: '<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p><?php echo e($error); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>',
                });
            </script>
<?php endif; ?>


<?php $__env->stopPush(); ?>



<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/pesos/modal/export.blade.php ENDPATH**/ ?>