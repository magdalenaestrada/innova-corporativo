

<?php $__env->startSection('content'); ?>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>
                <div class="card mt-3">

                    <div class="card-header d-flex justify-content-between align-items-center">
                            <div class="col-md-6">
                            <?php echo e(__('PERMISOS')); ?>

                            </div>
                            <div class="col-md-6 text-right">
                                <a href="<?php echo e(url('permissions/create')); ?>" class="btn btn-special float-end"> <?php echo e(__('CREAR NUEVO PERMISO')); ?></a>
                            </div>
                        
                    </div>


                  
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="font-size: 13px">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <tr>
                                    <td><?php echo e($permission->id); ?></td>
                                    <td><?php echo e($permission->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('permissions/'.$permission->id.'/edit')); ?>" class="btn btn-sm btn-success">Edit</a>
                                        <a href="<?php echo e(url('permissions/'.$permission->id.'/delete')); ?>" class="btn btn-sm btn-danger ">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/role-permission/permission/index.blade.php ENDPATH**/ ?>