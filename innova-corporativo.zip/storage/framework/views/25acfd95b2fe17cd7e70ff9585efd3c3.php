

<?php $__env->startSection('content'); ?>

<h2>Comienza un nuevo chat</h2>
<form action="<?php echo e(route('chats.start')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="recipient">Seleccione un usuario para chatear:</label>
    <select name="recipient_id" id="recipient" class="buscador" required>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->id !== auth()->id()): ?> <!-- Exclude the logged-in user -->
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-light" type="submit">Comenzar Chat</button>
</form>

<hr>

<h2>Tus Chats</h2>
<?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        // Determine the correct recipient name
        $recipient = ($chat->user_id === auth()->id()) ? $chat->recipient : $chat->user;
        $lastMessage = $chat->messages->first(); // Get the last message (already fetched in the query)

        // Determine if the last message is from the logged-in user or the recipient
        $lastMessageSender = $lastMessage && $lastMessage->user_id === auth()->id() ? 'Tú' : $recipient->name;
    ?>

    <?php if($lastMessage): ?>
        <a href="<?php echo e(route('chats.show', $chat)); ?>">
            <div class="card pl-3 pt-2">
                Chat con <?php echo e($recipient->name); ?>

                <p style="color:black">
                    <strong><?php echo e($lastMessageSender); ?>:</strong> <?php echo e($lastMessage->body); ?> 
                    <small style="color: #999"><?php echo e($lastMessage->created_at->format('d M Y, H:i')); ?></small>
                </p>
            </div>
        </a>    
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<hr>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        $('.buscador').select2({theme: "classic"});
        $('.buscador2').select2({theme: "classic"});
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/chats/index.blade.php ENDPATH**/ ?>