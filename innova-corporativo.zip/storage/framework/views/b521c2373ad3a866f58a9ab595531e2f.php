<div class="modal fade text-left" id="ModalDepositar"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('DEPOSITAR A CUENTA')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal" aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form class="crear-cuenta" action="<?php echo e(route('tssalidascuentas.depositar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        
                        <div class="form-group col-md-6 g-3">
                            <label for="cuenta" class="text-sm">
                                <?php echo e(__('CUENTA DE ORIGEN')); ?>

                            </label>
                            <br>
                            <select name="cuenta_id" id="cuenta1" class="form-control form-control-sm buscador <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" required="">
                                <option selected value="">
                                    Seleccione la cuenta de origen
                                </option>
                                <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cuenta->tipomoneda->nombre == 'SOLES'): ?>
                                    <option value="<?php echo e($cuenta->id); ?>" <?php echo e(old('cuenta') == $cuenta->id ? 'selected' : ''); ?>>
                                        <?php echo e($cuenta->nombre); ?>

                                    </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-6 g-3">
                            <label for="cuenta_beneficiaria_id" class="text-sm">
                                <?php echo e(__('CUENTA BENEFICIARIA')); ?>

                            </label>
                            <br>
                            <select name="cuenta_beneficiaria_id" id="cuenta_beneficiaria" class="form-control form-control-sm buscador <?php $__errorArgs = ['cuenta_beneficiaria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" required="">
                                <option selected value="">
                                    Seleccione la cuenta beneficiaria
                                </option>
                                <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cuenta->tipomoneda->nombre == 'SOLES'): ?>
                                    <option value="<?php echo e($cuenta->id); ?>" <?php echo e(old('cuenta_beneficiaria') == $cuenta->id ? 'selected' : ''); ?>>
                                        <?php echo e($cuenta->nombre); ?>

                                    </option>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cuenta_beneficiaria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        <div class="form-group col-md-6 g-3">
                            <label for="tipo_comprobante" class="text-sm">
                                <?php echo e(__('TIPO DE COMPROBANTE')); ?>

                            </label>
                            <br>
                            <select name="tipo_comprobante_id" id="tipo_comprobante2" class="form-control form-control-sm buscador <?php $__errorArgs = ['tipo_comprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" >
                                <option value="">
                                    Seleccione el tipo de comprobante
                                </option>
                                <?php $__currentLoopData = $tiposcomprobantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipocomprobante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tipocomprobante->id); ?>" <?php echo e(old('banco') == $tipocomprobante->id ? 'selected' : ''); ?>>
                                        <?php echo e($tipocomprobante->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['tipocomprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form col-md-6" style="margin-top: 28px">
                            <input name="comprobante_correlativo" id="comprobante_correlativo" class="form-control form-control-sm" placeholder="Ingrese el correlativo del comprobante"  type="text">
                            <span class="input-border"></span>
                        </div>   

                        

                        <div class="form-group col-md-12 g-3">
                            <label for="motivo" class="text-sm">
                                <?php echo e(__('MOTIVO')); ?>

                            </label>
                            <br>
                            <select name="motivo_id" id="motivo2" class="form-control form-control-sm buscador <?php $__errorArgs = ['motivo1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" required>
                                <option selected value="">
                                    Seleccione el motivo
                                </option>
                                <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($motivo->id); ?>" <?php echo e(old('cuenta') == $motivo->id ? 'selected' : ''); ?>>
                                        <?php echo e($motivo->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form col-md-12 mb-3">
                            <label for="descripcion" class="text-sm">
                                <?php echo e(__('DESCRIPCIÓN')); ?>

                            </label>
                            <input name="descripcion" id="descripcion" class=" form-control form-control-sm" placeholder="Ingrese una descripción" required="" type="text">
                            <span class="input-border"></span>
                        </div> 

                        
                        <div class="form col-md-6 mb-3">
                            <label for="fecha" class="text-sm">
                                <?php echo e(__('FECHA')); ?>

                            </label>
                            <input name="fecha" id="fecha" class="form-control form-control-sm" placeholder="Ingrese la fecha" type="date">
                            <span class="input-border"></span>
                        </div> 
                        


                        <div class="form col-md-6 mb-3">
                            <label for="nombre_salidacuenta" class="text-sm">
                                <?php echo e(__('MONTO')); ?>

                            </label>
                            <span class="text-danger">(*)</span>
                            <input name="monto" id="monto" class="form-control form-control-sm" placeholder="Ingrese el monto" required="" type="text">
                            <span class="input-border"></span>
                        </div>   


                        <div class="col-md-12 text-right g-3">
                            <button type="submit" class="btn btn-secondary btn-sm">
                                <?php echo e(__('GUARDAR')); ?>

                            </button>   
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/tesoreria/salidascuentas/modal/depositar.blade.php ENDPATH**/ ?>