

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/areas.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <br>
        <div class="row d-flex justify-content-between align-items-center">
            <div class="loader">
                <?php echo e(__('MOTIVOS DE LOS MOVIMIENTOS')); ?>


            </div>
            <div class="text-right col-md-6">
                <a class="" href="#" data-toggle="modal" data-target="#ModalCreate">
                    <button class="button-create">
                        <?php echo e(__('CREAR MOTIVO')); ?>

                    </button>

                </a>
            </div>

        </div>

        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">


                    <div class="card-body ">

                        <table id="posiciones-table" class="table table-striped  ">
                            <thead>
                                <tr>
                                    <th scope="col">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('NOMBRE')); ?>

                                    </th>

                                </tr>
                            </thead>

                            <tbody style="font-size: 13px">
                                <?php if(count($motivos) > 0): ?>
                                    <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row">
                                                <?php echo e($motivo->id); ?>

                                            </td>

                                            <td scope="row">
                                                <?php echo e($motivo->nombre); ?>


                                            </td>

                                            

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">
                                            <?php echo e(__('No hay datos disponibles')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- Pagination Links -->
                        <div class="d-flex justify-content-between">
                            <div>
                                <?php echo e($motivos->links('pagination::bootstrap-4')); ?>

                            </div>
                            <div>
                                Mostrando del <?php echo e($motivos->firstItem()); ?> al <?php echo e($motivos->lastItem()); ?> de
                                <?php echo e($motivos->total()); ?> registros
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php echo $__env->make('tesoreria.motivos.modal.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>

    <script>
        <?php if(session('status')): ?>
            Swal.fire('Éxito', '<?php echo e(session('status')); ?>', 'success');
        <?php elseif(session('error')): ?>
            Swal.fire('Error', '<?php echo e(session('error')); ?>', 'error');
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/tesoreria/motivos/index.blade.php ENDPATH**/ ?>