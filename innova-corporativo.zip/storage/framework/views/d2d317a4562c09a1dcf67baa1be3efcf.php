


<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header row d-flex justify-content-between align-items-center">
                        <div class="col-md-6">
                            <?php echo e(__('INGRESOS RÁPIDOS REGISTRADOS')); ?>


                        </div>
                        <div class="col-md-6 text-right">
                            <a class="btn btn-sm btn-special" href="#" data-toggle="modal" data-target="#ModalCreate">
                                <?php echo e(__('CREAR INGRESO RÁPIDO')); ?>

                            </a>
                        </div>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class=" text-center table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">
                                            <?php echo e(__('ID')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('FECHA DE CREACIÓN DE LA COMPRA')); ?>

                                        </th>



                                       



                                        <th scope="col">
                                            <?php echo e(__('PROVEEDOR')); ?>

                                        </th>


                                        <th scope="col" >
                                            <?php echo e(__('COSTO TOTAL')); ?>

                                        </th>



                                        <th scope="col">
                                            <?php echo e(__('ACCIÓN')); ?>

                                        </th>
                                    </tr>
                                </thead>

                                <tbody style="font-size:13px">
                                    <?php if(count($invingresosrapidos) > 0): ?>
                                        <?php $__currentLoopData = $invingresosrapidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invingresosrapido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td scope="row">
                                                    <?php echo e($invingresosrapido->id); ?>

                                                </td>
                                                <td scope="row">
                                                    <?php echo e($invingresosrapido->created_at); ?>

                                                </td>

                                                <?php if(is_array($invingresosrapido->productos) && count($invingresosrapido->productos) > 0): ?>
                                                    <td scope="row">
                                                        <?php echo e($invingresosrapido->productos[0]->nombre_producto); ?>

                                                    </td>
                                                <?php endif; ?>



                                                <td scope="row">
                                                    <?php if($invingresosrapido->proveedor): ?>
                                                        <?php echo e($invingresosrapido->proveedor->razon_social); ?>

                                                    <?php endif; ?>
                                                </td>


                                                <td scope="row" class="text-center">


                                                    <div class="d-flex justify-content-between pl-4">
                                                        <p>S/.</p> 
                                                    
                                                        <p><?php echo e(number_format($invingresosrapido->total, 2)); ?></p>
                                                            
                                                        
                                                    </div>
                                              
                                                </td>



                                                <td>
                                                    <div class="btn-group align-items-center">
                                                        <div>
                                                            <?php if($invingresosrapido->estado !== 'ANULADO'): ?>
                                                                <a href="<?php echo e(route('invingresosrapidos.anular', $invingresosrapido->id)); ?>"
                                                                    class="bin-button btn anular mr-1"
                                                                    style="margin-left: 5px;">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                        viewBox="0 0 39 7" class="bin-top">

                                                                        <line stroke-width="4" stroke="white" y2="5"
                                                                            x2="39" y1="5"></line>
                                                                        <line stroke-width="3" stroke="white" y2="1.5"
                                                                            x2="26.0357" y1="1.5" x1="12">
                                                                        </line>
                                                                    </svg>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                        viewBox="0 0 33 39" class="bin-bottom">
                                                                        <mask fill="white" id="path-1-inside-1_8_19">
                                                                            <path
                                                                                d="M0 0H33V35C33 37.2091 31.2091 39 29 39H4C1.79086 39 0 37.2091 0 35V0Z">
                                                                            </path>
                                                                        </mask>
                                                                        <path mask="url(#path-1-inside-1_8_19)"
                                                                            fill="white"
                                                                            d="M0 0H33H0ZM37 35C37 39.4183 33.4183 43 29 43H4C-0.418278 43 -4 39.4183 -4 35H4H29H37ZM4 43C-0.418278 43 -4 39.4183 -4 35V0H4V35V43ZM37 0V35C37 39.4183 33.4183 43 29 43V35V0H37Z">
                                                                        </path>
                                                                        <path stroke-width="4" stroke="white"
                                                                            d="M12 6L12 29"></path>
                                                                        <path stroke-width="4" stroke="white" d="M21 6V29">
                                                                        </path>
                                                                    </svg>
                                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                        viewBox="0 0 89 80" class="garbage">
                                                                        <path fill="white"
                                                                            d="M20.5 10.5L37.5 15.5L42.5 11.5L51.5 12.5L68.75 0L72 11.5L79.5 12.5H88.5L87 22L68.75 31.5L75.5066 25L86 26L87 35.5L77.5 48L70.5 49.5L80 50L77.5 71.5L63.5 58.5L53.5 68.5L65.5 70.5L45.5 73L35.5 79.5L28 67L16 63L12 51.5L0 48L16 25L22.5 17L20.5 10.5Z">
                                                                        </path>
                                                                    </svg>
                                                                </a>
                                                            <?php endif; ?>

                                                        </div>




                                                        <div class="">
                                                            <a class="btn btn-secondary btn-sm" href="#"
                                                                data-toggle="modal"
                                                                data-target="#ModalShow<?php echo e($invingresosrapido->id); ?>">
                                                                <?php echo e(__('VER')); ?>

                                                            </a>
                                                        </div>

                                                    </div>

                                                    <?php if($invingresosrapido->estado == 'ANULADO'): ?>
                                                        <p class="text-red">ANULADO</p>
                                                    <?php endif; ?>


                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10" class="text-center text-muted">
                                                <?php echo e(__('No hay datos disponibles')); ?>

                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end">
                                <li class="page-item <?php echo e($invingresosrapidos->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($invingresosrapidos->previousPageUrl()); ?>">
                                        <?php echo e(__('Anterior')); ?>

                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $invingresosrapidos->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($invingresosrapidos->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link"
                                            href="<?php echo e($invingresosrapidos->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo e($invingresosrapidos->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link" href="<?php echo e($invingresosrapidos->nextPageUrl()); ?>">
                                        <?php echo e(__('Siguiente')); ?>

                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php echo $__env->make('invingresosrapidos.modal.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php $__currentLoopData = $invingresosrapidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invingresosrapido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('invingresosrapidos.modal.show', ['id' => $invingresosrapido->id], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('js/updateadvice.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('js/jquery.printPage.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.btnprn').printPage();

        });
    </script>
    <script>
        <?php if(session('crear-ingreso-rapido') == 'Ingreso rapido creado con éxito.'): ?>
            Swal.fire('Ingreso rápido', 'creado exitosamente.', 'success');
        <?php elseif(session('crear-orden') == 'Orden de compra creada con éxito.'): ?>
            Swal.fire('Orden de compra', 'creada exitosamente.', 'success');
        <?php elseif(session('cancelar-orden-compra') == 'Orden de compra cancelada exitosamente.'): ?>
            Swal.fire('Orden de compra', 'cancelada con exito.', 'success');
        <?php elseif(session('actualizar-recepcion') == 'Recepción exitosa de productos.'): ?>
            Swal.fire('Ingreso al almacen', ' Productos recepcionados e ingresados al almacen con éxito.', 'success');
        <?php elseif(session('status') == 'Ingreso rápido anulado con éxito.'): ?>
            Swal.fire('Ingreso rápido', 'Anulado con éxito (revise su inventario).', 'success');
        <?php elseif(session('error')): ?>
            Swal.fire('Error', '<?php echo e(session('error')); ?>', 'error');
        <?php endif; ?>
    </script>
    <script>
        $(document).on('click', '.anular', function(e) {
            e.preventDefault();
            const url = $(this).attr('href');

            Swal.fire({
                title: '¿Está seguro que quiere eliminar este ingreso rápido?',
                text: 'Estos cambios no son reversibles',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: '¡Sí, continuar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Example of handling modal for cancellation
            $('.open-cancel-modal').click(function() {
                var id = $(this).data('id');
                $('#ModalCancelar' + id).modal('show');
            });
        });
    </script>



    <!-- Custom script to handle document search -->
    <script>
        $(document).ready(function() {
            function isRucOrDni(value) {
                return value.length === 8 || value.length === 11;
            }

            function buscarDocumento(url, inputId, datosId) {
                var inputValue = $(inputId).val();
                var tipoDocumento = inputValue.length === 8 ? 'dni' : 'ruc';

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        documento: inputValue,
                        tipo_documento: tipoDocumento
                    },
                    success: function(response) {
                        console.log('API Response:', response);
                        if (tipoDocumento === 'dni') {
                            $(datosId).val(response.nombres + ' ' + response.apellidoPaterno + ' ' +
                                response.apellidoMaterno);
                        } else {
                            $(datosId).val(response.razonSocial);
                        }
                        $(datosId).removeClass('is-invalid').addClass('is-valid');
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        $(datosId).val('');
                        $(datosId).removeClass('is-valid').addClass('is-invalid');
                    }
                });
            }

            // Button click handlers
            $('#buscar_cliente_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_cliente', '#datos_cliente');
            });

            $('#buscar_conductor_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_conductor',
                    '#datos_conductor');
            });

            $('#buscar_balanza_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_balanza', '#datos_balanza');
            });

            $('#buscar_socio_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_socio', '#datos_socio');
            });

            $('#buscar_trabajador_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_trabajador',
                    '#datos_trabajador');
            });

            $('#buscar_proveedor_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_proveedor',
                    '#datos_proveedor');
            });

            $('#buscar_solicitante_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_solicitante',
                    '#nombre_solicitante');
            });

            $('#buscar_responsable_btn').click(function() {
                buscarDocumento('<?php echo e(route('buscar.documento')); ?>', '#documento_responsable',
                    '#nombre_responsable');
            });

            // Input validation
            $('.documento-input').on('input', function() {
                var value = $(this).val();
                var isValid = isRucOrDni(value);
                $(this).toggleClass('is-valid', isValid);
                $(this).toggleClass('is-invalid', !isValid);
            });

            $('.datos-input').on('input', function() {
                var value = $(this).val();
                $(this).toggleClass('is-valid', value.trim().length > 0);
                $(this).toggleClass('is-invalid', value.trim().length === 0);
            });
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/invingresosrapidos/index.blade.php ENDPATH**/ ?>