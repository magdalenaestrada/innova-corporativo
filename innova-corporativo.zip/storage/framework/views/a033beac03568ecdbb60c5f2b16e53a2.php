

<?php $__env->startSection('content'); ?>
<br>
    <div class="container mt-4">
        <div class="card shadow-sm p-4">
            <h5>Reporte de consumo de combustible</h5>
            <form action="<?php echo e(route('nota-pedido.exportCombustible')); ?>" method="GET" class="row g-3 mt-3">
                <div class="col-md-4">
                    <label for="placa" class="form-label">Placa del vehículo</label>
                    <input type="text" name="placa" id="placa" class="form-control"
                        placeholder="(Dejar vacío para todas)">

                </div>
                <?php
                    use Carbon\Carbon;
                    $hoy = Carbon::now("America/Lima")->format("Y-m-d")
                ?>
                <div class="col-md-3">
                    <label for="desde" class="form-label">Desde</label>
                    <input type="date" name="desde" id="desde" class="form-control" max= <?php echo e($hoy); ?> required>
                </div>
                <div class="col-md-3">
                    <label for="hasta" class="form-label">Hasta</label>
                    <input type="date" name="hasta" id="hasta" class="form-control" max= <?php echo e($hoy); ?> value="<?php echo e($hoy); ?>" required>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-file-excel"></i> Exportar Excel
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/notas/reportes.blade.php ENDPATH**/ ?>