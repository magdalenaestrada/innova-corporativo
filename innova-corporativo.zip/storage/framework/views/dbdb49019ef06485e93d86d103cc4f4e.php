

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/areas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/modals.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/productos.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <br>

        <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Determine the correct recipient name
                $recipient = $chat->user_id === auth()->id() ? $chat->recipient : $chat->user;
                $lastMessage = $chat->messages->first(); // Get the last message (already fetched in the query)

                // Determine if the last message is from the logged-in user or the recipient
                $lastMessageSender = $lastMessage && $lastMessage->user_id === auth()->id() ? 'Tú' : $recipient->name;
            ?>

            <?php if($lastMessage && $lastMessage->is_read == false && $lastMessageSender != 'Tú'): ?>
                <div class="alert alert-success alert-dismissible fade show align-items-center" role="alert"
                    style="margin-top: -10px; 
            background-color: #D1E7DD;
            border: 1px solid #A3CFBB;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            font-size:12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: -10px;
            position: relative;
            font-family: sans-serif;
            
            ">
                    <a style="display: block; font-size: 13px; color: black; text-decoration: none;"
                        href="<?php echo e(route('chats.show', $chat)); ?>">
                        <strong>NUEVO MENSAJE DE</strong>
                        <?php echo e($lastMessageSender); ?>: <?php echo e($lastMessage->body); ?>

                        <small style="color: #999;"><?php echo e($lastMessage->created_at->format('d M Y, H:i')); ?></small>
                    </a>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <div class="row d-flex justify-content-between align-items-center">
            <div class="loader">
                <?php echo e(__('REGISTRO DE INGRESOS EN LAS CUENTAS')); ?>


            </div>
            <div class="text-right col-md-6">
                <a class="" href="#" data-toggle="modal" data-target="#ModalCreate">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit cuenta')): ?>
                        <button class="button-create">
                            <?php echo e(__('REGISTRAR INGRESO A LA CUENTA')); ?>

                        </button>
                    <?php endif; ?>
                </a>
            </div>

        </div>

        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="row">
                        <div class="col-md-6">
                            <input type="text" name="search" id="search" class="input-search form-control"
                                placeholder="Buscar Aquí...">
                        </div>
                    </div>





                    <div class=" d-flex justify-content-end">
                        <a href="#" class="button_export-excel" data-toggle="modal" data-target="#ModalExport">
                            <span class="button__text">
                                <svg fill="#fff" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                    viewBox="0 0 50 50">
                                    <path
                                        d="M28.8125 .03125L.8125 5.34375C.339844
                                                            5.433594 0 5.863281 0 6.34375L0 43.65625C0
                                                            44.136719 .339844 44.566406 .8125 44.65625L28.8125
                                                            49.96875C28.875 49.980469 28.9375 50 29 50C29.230469
                                                            50 29.445313 49.929688 29.625 49.78125C29.855469 49.589844
                                                            30 49.296875 30 49L30 1C30 .703125 29.855469 .410156 29.625
                                                            .21875C29.394531 .0273438 29.105469 -.0234375 28.8125 .03125ZM32
                                                            6L32 13L34 13L34 15L32 15L32 20L34 20L34 22L32 22L32 27L34 27L34
                                                            29L32 29L32 35L34 35L34 37L32 37L32 44L47 44C48.101563 44 49
                                                            43.101563 49 42L49 8C49 6.898438 48.101563 6 47 6ZM36 13L44
                                                            13L44 15L36 15ZM6.6875 15.6875L11.8125 15.6875L14.5 21.28125C14.710938
                                                            21.722656 14.898438 22.265625 15.0625 22.875L15.09375 22.875C15.199219
                                                            22.511719 15.402344 21.941406 15.6875 21.21875L18.65625 15.6875L23.34375
                                                            15.6875L17.75 24.9375L23.5 34.375L18.53125 34.375L15.28125
                                                            28.28125C15.160156 28.054688 15.035156 27.636719 14.90625
                                                            27.03125L14.875 27.03125C14.8125 27.316406 14.664063 27.761719
                                                            14.4375 28.34375L11.1875 34.375L6.1875 34.375L12.15625 25.03125ZM36
                                                            20L44 20L44 22L36 22ZM36 27L44 27L44 29L36 29ZM36 35L44 35L44 37L36 37Z">
                                    </path>
                                </svg>

                                Descargar
                            </span>
                            <span class="button__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 35"
                                    id="bdd05811-e15d-428c-bb53-8661459f9307" data-name="Layer 2" class="svg">
                                    <path
                                        d="M17.5,22.131a1.249,1.249,0,0,1-1.25-1.25V2.187a1.25,1.25,0,0,1,2.5,0V20.881A1.25,1.25,0,0,1,17.5,22.131Z">
                                    </path>
                                    <path
                                        d="M17.5,22.693a3.189,3.189,0,0,1-2.262-.936L8.487,15.006a1.249,1.249,0,0,1,1.767-1.767l6.751,6.751a.7.7,0,0,0,.99,0l6.751-6.751a1.25,1.25,0,0,1,1.768,1.767l-6.752,6.751A3.191,3.191,0,0,1,17.5,22.693Z">
                                    </path>
                                    <path
                                        d="M31.436,34.063H3.564A3.318,3.318,0,0,1,.25,30.749V22.011a1.25,1.25,0,0,1,2.5,0v8.738a.815.815,0,0,0,.814.814H31.436a.815.815,0,0,0,.814-.814V22.011a1.25,1.25,0,1,1,2.5,0v8.738A3.318,3.318,0,0,1,31.436,34.063Z">
                                    </path>
                                </svg></span>
                        </a>
                    </div>


                    <div class="card-body table-responsive">

                        <table id="ingresoscuentas-table" class="table table-striped  ">
                            <thead>
                                <tr class="text-center">

                                    <th scope="col">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('FECHA')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('TIPO')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('TIPO COMPROBANTE')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('NRO COMPROBANTE')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('CUENTA')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('MOTIVO')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('DESCRIPCIÓN')); ?>

                                    </th>


                                    <th scope="col">
                                        <?php echo e(__('ENTREGA')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('MONTO')); ?>

                                    </th>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit cuenta')): ?>
                                        <th scope="col">
                                            <?php echo e(__('ACCIÓN')); ?>

                                        </th>
                                    <?php endif; ?>
                                </tr>
                            </thead>

                            <tbody style="font-size: 13px">
                                <?php if(count($ingresoscuentas) > 0): ?>
                                    <?php $__currentLoopData = $ingresoscuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingresocuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">


                                            <td>
                                                <?php echo e($ingresocuenta->id); ?>

                                            </td>
                                            <td scope="row">
                                                <?php if($ingresocuenta->fecha): ?>
                                                    <?php echo e($ingresocuenta->fecha->format('d/m/Y')); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-success">INGRESO</span>
                                            </td>


                                            <td scope="row">
                                                <?php if($ingresocuenta->tipocomprobante): ?>
                                                    <?php echo e($ingresocuenta->tipocomprobante->nombre); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td scope="row">
                                                <?php if($ingresocuenta->comprobante_correlativo): ?>
                                                    <?php echo e($ingresocuenta->comprobante_correlativo); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>



                                            <td scope="row">
                                                <?php if($ingresocuenta->cuenta): ?>
                                                    <?php echo e($ingresocuenta->cuenta->nombre); ?>

                                                <?php endif; ?>
                                            </td>

                                            <td scope="row">
                                                <?php if($ingresocuenta->motivo): ?>
                                                    <?php echo e($ingresocuenta->motivo->nombre); ?>

                                                <?php endif; ?>
                                            </td>

                                            <td scope="row">
                                                <?php if($ingresocuenta->descripcion): ?>
                                                    <?php echo e($ingresocuenta->descripcion); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>



                                            <td scope="row">
                                                <?php if($ingresocuenta->cliente): ?>
                                                    <?php
                                                        $parts = explode(' ', $ingresocuenta->cliente->nombre);
                                                    ?>
                                                    <?php echo e($parts[0]); ?> <?php echo e(isset($parts[2]) ? $parts[2] : ''); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>


                                            <td>
                                                <?php
                                                    $coin_simbol =
                                                        $ingresocuenta->cuenta->tipomoneda->nombre == 'DOLARES'
                                                            ? '$'
                                                            : 'S/.';
                                                ?>
                                                <div class="d-flex justify-content-between">
                                                    <p><?php echo e($coin_simbol); ?></p>
                                                    <p> <?php echo e(number_format($ingresocuenta->monto, 2)); ?></p>
                                                </div>
                                            </td>


                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit cuenta')): ?>
                                                <td class="d-flex align-items-center">

                                                    <a href="<?php echo e(route('tsingresoscuentas.printdoc', $ingresocuenta->id)); ?>"
                                                        class="btnprn" style="margin-left: 5px;">



                                                        <div class="printer">
                                                            <div class="paper">

                                                                <svg viewBox="0 0 8 8" class="svg">
                                                                    <path fill="#0077FF"
                                                                        d="M6.28951 1.3867C6.91292 0.809799 7.00842 0 7.00842 0C7.00842 0 6.45246 0.602112 5.54326 0.602112C4.82505 0.602112 4.27655 0.596787 4.07703 0.595012L3.99644 0.594302C1.94904 0.594302 0.290039 2.25224 0.290039 4.29715C0.290039 6.34206 1.94975 8 3.99644 8C6.04312 8 7.70284 6.34206 7.70284 4.29715C7.70347 3.73662 7.57647 3.18331 7.33147 2.67916C7.08647 2.17502 6.7299 1.73327 6.2888 1.38741L6.28951 1.3867ZM3.99679 6.532C2.76133 6.532 1.75875 5.53084 1.75875 4.29609C1.75875 3.06133 2.76097 2.06018 3.99679 2.06018C4.06423 2.06014 4.13163 2.06311 4.1988 2.06905L4.2414 2.07367C4.25028 2.07438 4.26057 2.0758 4.27406 2.07651C4.81533 2.1436 5.31342 2.40616 5.67465 2.81479C6.03589 3.22342 6.23536 3.74997 6.23554 4.29538C6.23554 5.53084 5.23439 6.532 3.9975 6.532H3.99679Z">
                                                                    </path>
                                                                    <path fill="#0055BB"
                                                                        d="M6.756 1.82386C6.19293 2.09 5.58359 2.24445 4.96173 2.27864C4.74513 2.17453 4.51296 2.10653 4.27441 2.07734C4.4718 2.09225 5.16906 2.07947 5.90892 1.66374C6.04642 1.58672 6.1743 1.49364 6.28986 1.38647C6.45751 1.51849 6.61346 1.6647 6.756 1.8235V1.82386Z">
                                                                    </path>
                                                                </svg>

                                                            </div>





                                                            <div class="dot"></div>
                                                            <div class="output">
                                                                <div class="paper-out"></div>
                                                            </div>
                                                        </div>
                                                    </a>

                                                    <a href="#" data-toggle="modal"
                                                        data-target="#ModalEditar<?php echo e($ingresocuenta->id); ?>" class="">

                                                        <button class="editBtn" style="margin-left: 5px; margin-top:-3px">
                                                            <svg height="1em" viewBox="0 0 512 512">
                                                                <path
                                                                    d="M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z">
                                                                </path>
                                                            </svg>
                                                        </button>
                                                    </a>

                                                    <div class="">
                                                        <form class="eliminar-registro"
                                                            action="<?php echo e(route('tsingresoscuentas.destroy', $ingresocuenta->id)); ?>"
                                                            method="POST" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="bin-button btn anular eliminar-registro"
                                                                style="margin-left: 3px;">
                                                                <!-- SVG Icon -->
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                    viewBox="0 0 39 7" class="bin-top">
                                                                    <line stroke-width="4" stroke="white" y2="5"
                                                                        x2="39" y1="5"></line>
                                                                    <line stroke-width="3" stroke="white" y2="1.5"
                                                                        x2="26.0357" y1="1.5" x1="12">
                                                                    </line>
                                                                </svg>
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                    viewBox="0 0 33 39" class="bin-bottom">
                                                                    <mask fill="white" id="path-1-inside-1_8_19">
                                                                        <path
                                                                            d="M0 0H33V35C33 37.2091 31.2091 39 29 39H4C1.79086 39 0 37.2091 0 35V0Z">
                                                                        </path>
                                                                    </mask>
                                                                    <path mask="url(#path-1-inside-1_8_19)" fill="white"
                                                                        d="M0 0H33H0ZM37 35C37 39.4183 33.4183 43 29 43H4C-0.418278 43 -4 39.4183 -4 35H4H29H37ZM4 43C-0.418278 43 -4 39.4183 -4 35V0H4V35V43ZM37 0V35C37 39.4183 33.4183 43 29 43V35V0H37Z">
                                                                    </path>
                                                                    <path stroke-width="4" stroke="white" d="M12 6L12 29">
                                                                    </path>
                                                                    <path stroke-width="4" stroke="white" d="M21 6V29">
                                                                    </path>
                                                                </svg>
                                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                    viewBox="0 0 89 80" class="garbage">
                                                                    <path fill="white"
                                                                        d="M20.5 10.5L37.5 15.5L42.5 11.5L51.5 12.5L68.75 0L72 11.5L79.5 12.5H88.5L87 22L68.75 31.5L75.5066 25L86 26L87 35.5L77.5 48L70.5 49.5L80 50L77.5 71.5L63.5 58.5L53.5 68.5L65.5 70.5L45.5 73L35.5 79.5L28 67L16 63L12 51.5L0 48L16 25L22.5 17L20.5 10.5Z">
                                                                    </path>
                                                                </svg>
                                                            </button>
                                                        </form>

                                                    </div>
                                                </td>
                                            <?php endif; ?>




                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="13" class="text-center text-muted">
                                            <?php echo e(__('No hay datos disponibles')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- Pagination Links -->
                        <div class="d-flex justify-content-between">
                            <div>
                                <?php echo e($ingresoscuentas->links('pagination::bootstrap-4')); ?>

                            </div>
                            <div>
                                Mostrando del <?php echo e($ingresoscuentas->firstItem()); ?> al <?php echo e($ingresoscuentas->lastItem()); ?> de
                                <?php echo e($ingresoscuentas->total()); ?> registros
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php echo $__env->make('tesoreria.ingresoscuentas.modal.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('tesoreria.ingresoscuentas.modal.export', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(count($ingresoscuentas) > 0): ?>
        <?php $__currentLoopData = $ingresoscuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingresocuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('tesoreria.ingresoscuentas.modal.editar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>

    <script type="text/javascript" src="<?php echo e(asset('js/jquery.printPage.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.btnprn').printPage();

        });
    </script>


    <script>
        <?php if(session('status')): ?>
            Swal.fire('Éxito', '<?php echo e(session('status')); ?>', 'success');
        <?php elseif(session('error')): ?>
            Swal.fire('Error', '<?php echo e(session('error')); ?>', 'error');
        <?php endif; ?>
    </script>



    <script type="text/javascript">
        //SEARCHING FUNCTIONALITY
        $(document).ready(function() {
            //alert();

            //Search product
            $('#search').on('input', function(e) {
                e.preventDefault();
                let search_string = $(this).val();
                $.ajax({
                    url: "<?php echo e(route('search.ingresoscuentas')); ?>",
                    method: 'GET',
                    data: {
                        search_string: search_string
                    },
                    success: function(response) {

                        $('#ingresoscuentas-table tbody').html(response);
                    },
                    error: function(xhr, status, error) {}

                });



            });


        });


        //FINDING DOCUMENTO CLIENTE FUNCTIONALITY
        $('#nombrec').on('input', function(e) {
            e.preventDefault();
            let search_string = $(this).val();
            if (search_string.length >= 10) {
                $.ajax({
                    url: "<?php echo e(route('autocomp.cliente')); ?>",
                    method: 'GET',
                    data: {
                        search_string: search_string
                    },
                    success: function(response) {
                        console.log(1)

                        $('#documentoc').val(response.documento);

                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                    }
                });

            }
        });



        $('.eliminar-registro').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: '¿Eliminar ingreso a la cuenta?',
                text: 'Esta seguro que quiere eliminar este ingreso a la cuenta?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#0d0',
                confirmButtonText: '¡Sí, continuar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/tesoreria/ingresoscuentas/index.blade.php ENDPATH**/ ?>