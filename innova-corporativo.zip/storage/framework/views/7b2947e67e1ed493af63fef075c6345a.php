

<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="col-md-6">
                            <?php echo e(__('TODAS LAS PROGRAMACIONES REGISTRADAS')); ?>

                        </div>
                        <div class="col-md-6 text-right">
                            <a class="btn btn-sm btn-special" href="<?php echo e(route('programacion.create')); ?>">
                                <?php echo e(__('CREAR NUEVA PROGRAMACIÓN')); ?>

                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-hover">
                            <?php if(count($programaciones) > 0): ?>
                                <thead>
                                    <tr>
                                        <th scope="col">
                                            <?php echo e(__('ID')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('FECHA INICIO PROGRAMACIÓN')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('FECHA FIN PROGRAMACIÓN')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('FECHA INICIO EJECUCIÓN')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('FECHA FIN EJECUCIÓN')); ?>

                                        </th>


                                        <th class="text-center">
                                            <?php echo e(__('ACCIÓN')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $programaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row">
                                                <?php echo e($programacion->id); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($programacion->programacion_inicio); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($programacion->programacion_fin); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($programacion->ejecucion_inicio); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($programacion->ejecucion_finalizada); ?>

                                            </td>


                                            <td>
                                                <?php if($programacion->estado != 'finalizada'): ?>
                                                    <a href="<?php echo e(route('programacion.start', $programacion->id)); ?>"
                                                        class="btn btn-secondary btn-sm">
                                                        <?php echo e(__('INICIAR')); ?>

                                                    </a>
                                                    <a href="<?php echo e(route('programacion.finalizar', $programacion->id)); ?>"
                                                        class="btn btn-secondary btn-sm">
                                                        <?php echo e(__('FINALIZAR')); ?>

                                                    </a>
                                                    <a href="<?php echo e(route('programacion.show', $programacion->id)); ?>"
                                                        class="btn btn-warning btn-sm">
                                                        <?php echo e(__('VER')); ?>

                                                    </a>
                                                    <form class="eliminar-registro"
                                                        action="<?php echo e(route('programacion.destroy', $programacion->id)); ?>"
                                                        method="POST" style="display: inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm">
                                                            <?php echo e(__('ELIMINAR')); ?>

                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('programacion.show', $programacion->id)); ?>"
                                                        class="btn btn-warning btn-sm">
                                                        <?php echo e(__('VER')); ?>

                                                    </a>
                                                <?php endif; ?>

                                            </td>




                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted">
                                        <?php echo e(__('No hay datos disponibles')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end">
                                <li class="page-item <?php echo e($programaciones->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($programaciones->previousPageUrl()); ?>">
                                        <?php echo e(__('Anterior')); ?>

                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $programaciones->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($programaciones->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($programaciones->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo e($programaciones->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link" href="<?php echo e($programaciones->nextPageUrl()); ?>">
                                        <?php echo e(__('Siguiente')); ?>

                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <script src="<?php echo e(asset('js/updateadvice.js')); ?>"></script>

        <script>
            <?php if(session('eliminar-programacion') == 'Programacion eliminada con éxito.'): ?>
                Swal.fire('Programación', 'eliminado exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('crear-programacion') == 'Programación creada con éxito.'): ?>
                Swal.fire('Programación', 'creada exitosamente.', 'success')
            <?php endif; ?>
            <?php if(session('editar-programaxion') == 'Programación actualizado con éxito.'): ?>
                Swal.fire('Programación', 'actualizado exitosamente.', 'success')
            <?php endif; ?>
        </script>
        <script>
            $('.eliminar-registro').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: '¿Eliminar registro?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '¡Sí, continuar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/programacion/index.blade.php ENDPATH**/ ?>