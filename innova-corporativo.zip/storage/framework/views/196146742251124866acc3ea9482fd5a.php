<div class="modal fade text-left" id="ModalShow<?php echo e($invingresosrapido->id); ?>" tabindex="-1" role="dialog"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('INGRESO RÁPIDO')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal"
                            aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">

                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">

                <div class="row">

                    <div class="form-group col-md-6 g-3">
                        <label for="inventariosalida_fin" class="text-sm">
                            <?php echo e(__('FECHA DE CREACIÓN')); ?>

                        </label>
                        <input class="form-control form-control-sm" value="<?php echo e($invingresosrapido->created_at); ?>"
                            disabled>
                    </div>

                    <div class="form-group col-md-6 g-3">
                        <label for="inventariosalida_fin" class="text-sm">
                            <?php echo e(__('CREADOR')); ?>

                        </label>
                        <input class="form-control form-control-sm" value="<?php echo e($invingresosrapido->usuario_creador); ?>"
                            disabled>
                    </div>

                    <div class="mt-2 col-md-12 table-responsive">
                        <?php if(count($invingresosrapido->productos) > 0): ?>
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr class="text-center">

                                        <th scope="col">
                                            <?php echo e(__('PRODUCTO DEL REQUERIMIENTO')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('CANTIDAD')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('VALOR UNITARIO')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('SUBTOTAL')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('FECHA DE CREACIÓN')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $invingresosrapido->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td scope="row">
                                                <?php echo e($producto->nombre_producto); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($producto->pivot->cantidad); ?>

                                            </td>

                                            <td scope="row">
                                                s/<?php echo e($producto->pivot->precio); ?>

                                            </td>

                                            <td scope="row">
                                                s/<?php echo e($producto->pivot->subtotal); ?>

                                            </td>

                                            <td scope="row">
                                                <?php echo e($producto->pivot->created_at); ?>

                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-12 m-2">
                        <?php if($invingresosrapido->subtotal): ?>
                            <p class="text-center h6"> SUBTOTAL: S/.
                                <?php echo e(number_format($invingresosrapido->subtotal, 2)); ?></p>
                        <?php endif; ?>

                        <p class="text-center h5"> IMPORTE TOTAL: S/. <?php echo e(number_format($invingresosrapido->total, 2)); ?>

                        </p>

                    </div>

                    <div class="form-group col-md-6 g-3">
                        <label for="inventariosalida_fin" class="text-sm">
                            <?php echo e(__('TIPO COMPROBANTE')); ?>

                        </label>
                        <input class="form-control form-control-sm" value="<?php echo e($invingresosrapido->tipo_comprobante); ?>"
                            disabled>
                    </div>

                    <div class="form-group col-md-6 g-3">
                        <label for="inventariosalida_fin" class="text-sm">
                            <?php echo e(__('COMPROBANTE CORRELATIVO')); ?>

                        </label>
                        <input class="form-control form-control-sm"
                            value="<?php echo e($invingresosrapido->comprobante_correlativo); ?>" disabled>
                    </div>

                    <?php if($invingresosrapido->proveedor): ?>
                        <div class="form-group col-md-4 g-3">
                            <label for="documento_proveedor" class="text-sm">
                                <?php echo e(__('DOCUMENTO PROVEEDOR')); ?>

                            </label>
                            <div class="input-group">
                                <input class="form-control form-control-sm"
                                    value="<?php echo e($invingresosrapido->proveedor->ruc); ?>" disabled>

                            </div>
                        </div>
                        <div class="form-group col-md-8 g-3">
                            <label for="nombre_proveedor" class="text-sm">
                                <?php echo e(__('NOMBRE PROVEEDOR')); ?>

                            </label>
                            <input class="form-control form-control-sm"
                                value="<?php echo e($invingresosrapido->proveedor->razon_social); ?>" disabled>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/invingresosrapidos/modal/show.blade.php ENDPATH**/ ?>