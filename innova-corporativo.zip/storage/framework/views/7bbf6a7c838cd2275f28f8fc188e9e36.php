<div class="modal fade text-left" id="ModalExport"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('REPORTE DE INGRESOS A LAS CUENTAS')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal" aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form class="crear-accion" action="<?php echo e(route('tsingresoscuentas.export-excel')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="form-group col-md-6 g-3">
                            <label for="tipo_comprobante" class="text-muted">
                                <?php echo e(__('TIPO DE COMPROBANTE')); ?>

                            </label>
                            <br>
                            <select name="tipo_comprobante_id" id="tipo_comprobante1" class="form-control buscador <?php $__errorArgs = ['tipo_comprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" >
                                <option value="">
                                    Seleccione el tipo de comprobante
                                </option>
                                <?php $__currentLoopData = $tiposcomprobantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipocomprobante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tipocomprobante->id); ?>" <?php echo e(old('banco') == $tipocomprobante->id ? 'selected' : ''); ?>>
                                        <?php echo e($tipocomprobante->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['tipocomprobante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-6 g-3">
                            <label for="motivo" class="text-muted">
                                <?php echo e(__('MOTIVO')); ?>

                            </label>
                            <br>
                            <select name="motivo_id" id="motivo2" class="form-control buscador <?php $__errorArgs = ['motivo1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" >
                                <option selected value="">
                                    Seleccione el motivo
                                </option>
                                <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($motivo->id); ?>" <?php echo e(old('cuenta') == $motivo->id ? 'selected' : ''); ?>>
                                        <?php echo e($motivo->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group col-md-6 g-3">
                            <label for="cuenta" class="text-muted">
                                <?php echo e(__('CUENTA')); ?>

                            </label>
                            <br>
                            <select name="cuenta_id" id="cuenta3" class="form-control buscador <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" >
                                <option selected value="">
                                    Seleccione la cuenta
                                </option>
                                <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cuenta->id); ?>" <?php echo e(old('cuenta') == $cuenta->id ? 'selected' : ''); ?>>
                                        <?php echo e($cuenta->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                      
                        <div class="col-md-6"></div>


                        <div class="form-group col-md-6 g-3">
                            <label for="start_date" class="text-muted">
                                <?php echo e(__('FECHA INICIAL')); ?>

                            </label>
                            <input type="datetime-local" name="start_date" placeholder="Ingrese la fecha Inicial"
                                class="form-control">
                        </div>

                        <div class="form-group col-md-6 g-3">
                            <label for="end_date" class="text-muted">
                                <?php echo e(__('FECHA FINAL')); ?>

                            </label>
                            <input type="datetime-local" name="end_date" placeholder="Ingrese la fecha Final"
                                class="form-control">
                        </div>

                        

                        
                       
                        
                       

                      
                        <div class="col-md-12 text-right g-3">
                            <button type="submit" class="btn btn-secondary btn-sm">
                                <?php echo e(__('EXPORTAR REPORTE')); ?>

                            </button>   
                        </div>
                    </div>
                </form>
            </div>
        
        </div>
    </div>
</div>
<?php $__env->startPush('js'); ?>
<script>
            $('.crear-producto').submit(function(e){
                e.preventDefault();
                Swal.fire({
                    title: '¿Crear producto?',
                    icon: 'warning',
                    ShowCancelButton: true,
                    ConfirmButtonColor: '#3085d6',
                    CancelButtonColor: '#d33',
                    ConfirmButtonText: '¡Si, confirmar!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if(result.isConfirmed){
                        this.submit();
                    }
                })
            });
</script>


<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    
    
    $(document).ready(function() {
        $('.buscador').select2({theme: "classic"});
    });
</script>

<?php if($errors->any()): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error de validación',
                    html: '<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p><?php echo e($error); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>',
                });
            </script>
<?php endif; ?>


<?php $__env->stopPush(); ?>



<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/tesoreria/ingresoscuentas/modal/export.blade.php ENDPATH**/ ?>