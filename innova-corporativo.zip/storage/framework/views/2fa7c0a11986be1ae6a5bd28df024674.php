

<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div class="col-md-6">
                            <?php echo e(__('TODOS LOS TICKETS DEL COMEDOR REGISTRADOS')); ?>


                        </div>
                        <div class="col-md-6 text-right">

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create comedor')): ?>
                                <a class="btn btn-sm btn-special" href="<?php echo e(route('ranchos.create')); ?>">
                                    <?php echo e(__('CREAR NUEVO TICKET PARA EL COMEDOR')); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body mt-2">
                        <table class="table table-striped table-hover" style="font-size: 13px; margin-bottom:10px">
                            <?php if(count($ranchos) > 0): ?>
                                <thead>
                                    <tr>
                                        <th scope="col">
                                            <?php echo e(__('ID')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('DOCUMENTO CLIENTE')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('DATOS CLIENTE')); ?>

                                        </th>

                                        <th scope="col">
                                            <?php echo e(__('DOCUMENTO COMENSAL')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('DATOS COMENSAL')); ?>

                                        </th>

                                        <th scope="col">
                                            <?php echo e(__('ESTADO')); ?>

                                        </th>
                                        <th scope="col">
                                            <?php echo e(__('CANTIDAD')); ?>

                                        </th>

                                        <th scope="col">
                                            <?php echo e(__('LOTE')); ?>

                                        </th>


                                        <th>
                                            <?php echo e(__('ACCIÓN')); ?>

                                        </th>
                                    </tr>
                                </thead>
                                <tbody style="font-size: 13px">
                                    <?php $__currentLoopData = $ranchos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rancho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row">
                                                <?php echo e($rancho->id); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($rancho->documento_cliente); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($rancho->datos_cliente); ?>

                                            </td>

                                            <td scope="row">
                                                <?php echo e($rancho->documento_trabajador); ?>

                                            </td>
                                            <td scope="row">
                                                <?php echo e($rancho->datos_trabajador); ?>

                                            </td>


                                            <td scope="row">
                                                <?php echo e($rancho->estado); ?>

                                            </td>

                                            <td scope="row">
                                                <?php echo e($rancho->cantidad); ?>

                                            </td>

                                            <td scope="row">
                                                <?php echo e($rancho->lote); ?>

                                            </td>

                                            <td>
                                                <div class="btn-group align-items-center">

                                                    <a href="<?php echo e(route('ranchos.show', $rancho->id)); ?>"
                                                        class="btn btn-secondary btn-sm mr-1" style="height: 33px">
                                                        <?php echo e(__('VER')); ?>

                                                    </a>

                                                    <?php if($rancho->estado == 'abierto'): ?>
                                                        <a href="<?php echo e(route('ticket.prnpriview', $rancho->id)); ?>"
                                                            class="btnprn btn btn-info btn-sm mr-1"
                                                            style="height:33px">IMPRIMIR</a>
                                                    <?php endif; ?>

                                                    <?php if($rancho->estado == 'impreso'): ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print always')): ?>
                                                            <a href="<?php echo e(route('ticket.prnpriview', $rancho->id)); ?>"
                                                                class="btnprn btn btn-info btn-sm mr-1"
                                                                style="height:33px">IMPRIMIR</a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete ticket')): ?>
                                                        <form class="eliminar-ticket"
                                                            action="<?php echo e(route('ranchos.destroy', $rancho->id)); ?>" method="POST"
                                                            style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger btn-sm mr-1">
                                                                <?php echo e(__('ELIMINAR')); ?>

                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted">
                                        <?php echo e(__('No hay datos disponibles')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>


                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-end flex-wrap">
                                <!-- Previous Page Link -->
                                <li class="page-item <?php echo e($ranchos->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(request()->fullUrlWithQuery(['page' => $ranchos->currentPage() - 1])); ?>"
                                        aria-label="Previous">
                                        <span aria-hidden="true"><?php echo e(__('Anterior')); ?></span>
                                    </a>
                                </li>

                                <!-- First 7 Pages -->
                                <?php for($i = 1; $i <= 7 && $i <= $ranchos->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($ranchos->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link"
                                            href="<?php echo e(request()->fullUrlWithQuery(['page' => $i])); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Ellipsis if needed before middle pages -->
                                <?php if($ranchos->currentPage() > 10): ?>
                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>

                                <!-- Middle Pages (2 before and 2 after current page) -->
                                <?php for($i = max(8, $ranchos->currentPage() - 2); $i <= min($ranchos->lastPage() - 7, $ranchos->currentPage() + 2); $i++): ?>
                                    <?php if($i > 7 && $i < $ranchos->lastPage() - 6): ?>
                                        <li class="page-item <?php echo e($ranchos->currentPage() == $i ? 'active' : ''); ?>">
                                            <a class="page-link"
                                                href="<?php echo e(request()->fullUrlWithQuery(['page' => $i])); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <!-- Ellipsis if needed before last 7 pages -->
                                <?php if($ranchos->currentPage() < $ranchos->lastPage() - 10): ?>
                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                <?php endif; ?>

                                <!-- Last 7 Pages -->
                                <?php for($i = max($ranchos->lastPage() - 6, 8); $i <= $ranchos->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($ranchos->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link"
                                            href="<?php echo e(request()->fullUrlWithQuery(['page' => $i])); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Next Page Link -->
                                <li class="page-item <?php echo e($ranchos->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link"
                                        href="<?php echo e(request()->fullUrlWithQuery(['page' => $ranchos->currentPage() + 1])); ?>"
                                        aria-label="Next">
                                        <span aria-hidden="true"><?php echo e(__('Siguiente')); ?></span>
                                    </a>
                                </li>
                            </ul>
                        </nav>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="<?php echo e(asset('js/updateadvice.js')); ?>"></script>

    <script type="text/javascript" src="js/jquery.printPage.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.btnprn').printPage();

        });
    </script>
    <script>
        <?php if(session('eliminar-ticket') == 'Ticket eliminado con éxito'): ?>
            Swal.fire('Ticket', 'eliminado exitosamente.', 'success')
        <?php endif; ?>
        <?php if(session('crear-registro') == 'Registro creado con éxito.'): ?>
            Swal.fire('Registro', 'creado exitosamente.', 'success')
        <?php endif; ?>
        <?php if(session('editar-registro') == 'Registro actualizado con éxito.'): ?>
            Swal.fire('Registro', 'actualizado exitosamente.', 'success')
        <?php endif; ?>
    </script>
    <script>
        $('.eliminar-registro').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: '¿Eliminar registro?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '¡Sí, continuar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            })
        });
    </script>
    <script type="text/javascript">
        $('.eliminar-ticket').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Está seguro que quiere eliminar este ticket?',
                text: 'Estos cambios no son reversibles',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: '¡Sí, continuar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            })
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/ranchos/index.blade.php ENDPATH**/ ?>