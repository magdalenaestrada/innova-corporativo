<div class="modal fade text-left" id="ModalCambiarDolares"  role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">

            <div class="card-header">
                <div class="row justify-content-between">
                    <div class="col-md-6">
                        <h6 class="mt-2">
                            <?php echo e(__('CAMBIAR DOLARES A SOLES')); ?>

                        </h6>
                    </div>
                    <div class="col-md-6 text-right">
                        <button type="button" style="font-size: 30px" class="close" data-dismiss="modal" aria-label="Close">
                            <img style="width: 15px" src="<?php echo e(asset('images/icon/close.png')); ?>" alt="cerrar">
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form class="crear-cuenta" action="<?php echo e(route('tssalidascuentas.depositar')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        
                     



                        
                        <div class="form-group col-md-6 g-3">
                            <label for="cuenta" class="text-sm">
                                <?php echo e(__('CUENTA DE ORIGEN')); ?>

                            </label>
                            <br>
                            <select name="cuenta_id" id="cuenta2" class="form-control form-control-sm buscador <?php $__errorArgs = ['cuenta1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" required="">
                                <option selected value="">
                                    Seleccione la cuenta en dolares
                                </option>
                                <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cuenta->tipomoneda->nombre == 'DOLARES'): ?>
                                    <option value="<?php echo e($cuenta->id); ?>" <?php echo e(old('cuenta1') == $cuenta->id ? 'selected' : ''); ?>>
                                        <?php echo e($cuenta->nombre); ?>

                                    </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cuenta1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-6 g-3">
                            <label for="cuenta_beneficiaria_id" class="text-sm">
                                <?php echo e(__('CUENTA BENEFICIARIA')); ?>

                            </label>
                            <br>
                            <select name="cuenta_beneficiaria_id" id="cuenta_beneficiaria1" class="form-control form-control-sm buscador <?php $__errorArgs = ['cuenta_beneficiaria1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" required="">
                                <option selected value="">
                                    Seleccione la cuenta en soles
                                </option>
                                <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cuenta->tipomoneda->nombre == 'SOLES'): ?>
                                    <option value="<?php echo e($cuenta->id); ?>" <?php echo e(old('cuenta_beneficiaria1') == $cuenta->id ? 'selected' : ''); ?>>
                                        <?php echo e($cuenta->nombre); ?>

                                    </option>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cuenta_beneficiaria1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        

                        <div class="form-group col-md-6 g-3">
                            <label for="motivo" class="text-sm">
                                <?php echo e(__('MOTIVO')); ?>

                            </label>
                            <br>
                            <select name="motivo_id" id="motivo1" class="form-control form-control-sm buscador <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="" style="width: 100%" required>
                                <option selected value="">
                                    Seleccione el motivo
                                </option>
                                <?php $__currentLoopData = $motivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($motivo->id); ?>" <?php echo e(old('cuenta') == $motivo->id ? 'selected' : ''); ?>>
                                        <?php echo e($motivo->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form col-md-6 mb-3">
                            <label for="fecha" class="text-sm">
                                <?php echo e(__('FECHA')); ?>

                            </label>
                            <input name="fecha" id="fecha" class="form-control form-control-sm" placeholder="Ingrese la fecha" type="date">
                            <span class="input-border"></span>
                        </div> 
                        



                        <div class="form col-md-12 mb-3">
                            <label for="descripcion" class="text-sm">
                                <?php echo e(__('DESCRIPCIÓN')); ?>

                            </label>
                            <input name="descripcion" id="descripcion" class="form-control form-control-sm" placeholder="Ingrese la descripción" required="" type="text">
                            <span class="input-border"></span>
                        </div> 


                        <div class="form col-md-4 mb-3">
                            <label for="monto" class="text-sm">
                                <?php echo e(__('MONTO')); ?>

                            </label>
                            <input name="monto" id="monto1" class="form-control form-control-sm" placeholder="Ingrese el monto" required="" type="text">
                            <span class="input-border"></span>
                        </div>   


                        <div class="form col-md-4 mb-3">
                            <label for="tipo_cambio" class="text-sm">
                                <?php echo e(__('TIPO DE CAMBIO')); ?>

                            </label>
                            <input name="tipo_cambio" id="tipocambio" class="form-control form-control-sm" placeholder="Ingrese el tipo de cambio" required="" type="text">
                            <span class="input-border"></span>
                        </div>   

                        <div class="form col-md-4 mb-3">

                            <label for="total" class="text-sm">
                                <?php echo e(__('TOTAL')); ?>

                            </label>
                            <input name="total" id="total" class="form-control form-control-sm" placeholder="TOTAL" required="" type="text">
                            <span class="input-border"></span>
                        </div>   



                        <div class="col-md-12 text-right g-3">
                            <button type="submit" class="btn btn-secondary btn-sm">
                                <?php echo e(__('GUARDAR')); ?>

                            </button>   
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/tesoreria/salidascuentas/modal/cambiardolares.blade.php ENDPATH**/ ?>