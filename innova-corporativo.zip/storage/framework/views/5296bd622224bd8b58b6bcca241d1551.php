

<?php $__env->startSection('content'); ?>
    <br>
    <div class="container mt-4">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">CREAR NOTA DE PEDIDO</h5>
                <a href="<?php echo e(route('nota-pedido.index')); ?>" class="btn btn-secondary btn-sm">Volver</a>
            </div>
            <?php
                use Carbon\Carbon;
                $hoy = Carbon::now('America/Lima')->format('Y-m-d');
            ?>
            <div class="card-body">
                <form action="<?php echo e(route('nota-pedido.store')); ?>" method="POST" id="formNotaPedido">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <label for="dni" class="form-label">DNI</label>
                            <div class="input-group">
                                <input type="text" name="dni" class="form-control modern-input" maxlength="9"
                                    inputmode="numeric" pattern="\d*" required>
                                <button class="btn btn-success" type="button" id="buscar_dni_btn">Buscar</button>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label for="proveedor" class="form-label">Conductor</label>
                            <input type="text" name="proveedor" id="nombre" class="form-control" required
                                placeholder="Nombre del conductor">

                        </div>
                        <div class="col-md-3">
                            <label for="placa_vehiculo" class="form-label">Placa</label>
                            <input type="text" name="placa_vehiculo" class="form-control modern-input"
                                pattern="^[A-Za-z0-9]+-[A-Za-z0-9]+$"
                                placeholder="Ejemplo: ABC-123"
                                title="Debe contener letras y números separados por un guion medio (Ejemplo: ABC-123 )"
                                maxlength="10" required>
                        </div>
                       <div class="col-md-2">
                        <label for="kilometraje" class="form-label">Kilometraje</label>
                        <input type="number" name="kilometraje" class="form-control modern-input" step="0.01" min="0" placeholder="Ejemplo: 125.75">
                    </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <label for="fecha_creacion" class="form-label">Fecha</label>
                            <input type="date" name="fecha_creacion" id="fecha_creacion" class="form-control"
                                max="<?php echo e($hoy); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="encargado_id" class="form-label">Encargado</label>
                            <select name="encargado_id" id="encargado_id" class="form-control" required>
                                <option value="">-- Seleccione un encargado --</option>
                                <?php $__currentLoopData = $encargados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encargado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($encargado->id); ?>"><?php echo e($encargado->nombre ?? $encargado->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class="col-md-3">
                            <label for="telefono" class="form-label">Teléfono</label>
                            <input type="number" name="telefono" id="telefono" class="form-control">
                        </div>
                    </div>

                    <hr>
                    <h6 class="mb-3">Productos</h6>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th class="text-center">
                                        <button class="btn btn-success btn-sm" type="button" id="addMoreButton">+
                                            Añadir</button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="table_body" style="font-size: 15px">
                                <tr>
                                    <td>
                                        <select name="products[]" class="form-control buscador cart-product" required>
                                            <option value="">-- Seleccione una opción --</option>
                                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre_producto); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input name="qty[]" class="form-control form-control-sm" required
                                            placeholder="0.0">
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-danger btn-sm" type="button"
                                            onclick="remove_tr(this)">✕</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <input type="hidden" name="detalles" id="inputDetalles">

                    <div class="text-end mt-3">
                        <button type="submit" class="btn btn-success">Guardar Nota de Pedido</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        // === Agregar nueva fila ===
        document.getElementById('addMoreButton').addEventListener('click', function() {
            const fila = `
            <tr>
                <td>
                    <select name="products[]" class="form-control buscador cart-product" required>
                        <option value="">-- Seleccione una opción --</option>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre_producto); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <td>
                    <input name="qty[]" class="form-control form-control-sm" required placeholder="0.0">
                </td>
                <td class="text-center">
                    <button class="btn btn-danger btn-sm" type="button" onclick="remove_tr(this)">✕</button>
                </td>
            </tr>`;
            $('#table_body').append(fila);
        });

        // === Eliminar fila ===
        function remove_tr(button) {
            $(button).closest('tr').remove();
        }

        // === Serializar y enviar datos por AJAX ===
        $('#formNotaPedido').on('submit', function(e) {
            e.preventDefault(); // Evita que se recargue la página

            const detalles = [];
            $('#table_body tr').each(function() {
                const producto = $(this).find('select').val();
                const cantidad = $(this).find('input').val();
                if (producto && cantidad) {
                    detalles.push({
                        producto,
                        cantidad
                    });
                }
            });
            $('#inputDetalles').val(JSON.stringify(detalles));

            const formData = $(this).serialize();

            $.ajax({
                url: "<?php echo e(route('nota-pedido.store')); ?>",
                type: "POST",
                data: formData,
                success: function(res) {
                    if (res.success) {
                        Swal.fire({
                            icon: "success",
                            title: "Éxito",
                            text: res.message,
                            timer: 2000,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.href = "<?php echo e(route('nota-pedido.index')); ?>";
                        });
                    } else {
                        Swal.fire({
                            icon: "warning",
                            title: "Atención",
                            text: res.message,
                        });
                    }
                },
                error: function(xhr) {
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: "Ocurrió un problema al registrar la nota.",
                    });
                },
            });
        });


        $(document).ready(function() {
            $("#buscar_dni_btn").on("click", function() {
                const documento = $("input[name='dni']").val().trim();

                if (documento === "") {
                    alert("Por favor, ingrese un DNI.");
                    return;
                }

                $.ajax({
                    url: "<?php echo e(route('buscar.documento')); ?>",
                    type: "POST",
                    data: {
                        documento: documento,
                        _token: "<?php echo e(csrf_token()); ?>",
                    },
                    success: function(response) {
                        if (response.nombres) {
                            $("#nombre").val(response.nombres + " " + response.apellidoPaterno +
                                " " + response.apellidoMaterno);
                        } else if (response.razonSocial) {
                            $("#nombre").val(response.razonSocial);
                        } else {
                            alert("No se encontraron datos.");
                        }
                    },
                    error: function() {
                        alert("Ocurrió un error al consultar el documento.");
                    },
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/notas/formulario.blade.php ENDPATH**/ ?>