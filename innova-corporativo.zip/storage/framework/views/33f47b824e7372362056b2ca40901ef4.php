

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/areas.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <br>
        <div class="row d-flex justify-content-between align-items-center">
            <div class="loader">
                <?php echo e(__('CAJAS REGISTRADAS')); ?>


            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit cuenta')): ?>
                <div class="text-right col-md-6">
                    <a class="" href="#" data-toggle="modal" data-target="#ModalCreate">
                        <button class="button-create">
                            <?php echo e(__('CREAR CAJA')); ?>

                        </button>

                    </a>
                </div>
            <?php endif; ?>

        </div>

        <br>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">


                    <div class="card-body ">

                        <table id="cajas-table" class="table table-striped  ">
                            <thead>
                                <tr class="text-center">
                                    <th scope="col">
                                        <?php echo e(__('ID')); ?>

                                    </th>
                                    <th scope="col">
                                        <?php echo e(__('NOMBRE')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('ENCARGADO')); ?>

                                    </th>

                                    <th scope="col">
                                        <?php echo e(__('BALANCE')); ?>

                                    </th>

                                </tr>
                            </thead>

                            <tbody style="font-size: 13px">
                                <?php if(count($cajas) > 0): ?>
                                    <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td scope="row">
                                                <?php echo e($caja->id); ?>

                                            </td>

                                            <td scope="row">
                                                <?php echo e(strtoupper($caja->nombre)); ?>


                                            </td>

                                            <td scope="row">
                                                <?php if($caja->encargados): ?>
                                                    <?php $__currentLoopData = $caja->encargados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encargado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge bg-info"><?php echo e(strtoupper($encargado->nombre)); ?>

                                                        </span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>


                                            <td scope="row">

                                                <div class="d-flex justify-content-between">
                                                    <p class="">S/.</p>

                                                    <?php
                                                        $ingresosTotal = $caja->reposiciones->sum('salidacuenta.monto');
                                                        $salidasTotal = $caja->salidascajas->sum('monto');

                                                        $new_bal = $ingresosTotal - $salidasTotal;
                                                    ?>

                                                    <p class="mr-3  "> <?php echo e(number_format($new_bal, 2)); ?></p>


                                                </div>

                                            </td>

                                            

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">
                                            <?php echo e(__('No hay datos disponibles')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- Pagination Links -->
                        <div class="d-flex justify-content-between">
                            <div>
                                <?php echo e($cajas->links('pagination::bootstrap-4')); ?>

                            </div>
                            <div>
                                Mostrando del <?php echo e($cajas->firstItem()); ?> al <?php echo e($cajas->lastItem()); ?> de
                                <?php echo e($cajas->total()); ?> registros
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php echo $__env->make('tesoreria.cajas.modal.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag@2.0.1/dist/js/multi-select-tag.js"></script>

    <script>
        new MultiSelectTag('encargados', {
            rounded: true, // default true
            shadow: true, // default false
            placeholder: 'Search', // default Search...
            tagColor: {
                textColor: '#fff',
                borderColor: '#000',
                bgColor: '#000',
            },
            onChange: function(values) {
                console.log(values)
            }
        })

        <?php if(session('status')): ?>
            Swal.fire('Éxito', '<?php echo e(session('status')); ?>', 'success');
        <?php elseif(session('error')): ?>
            Swal.fire('Error', '<?php echo e(session('error')); ?>', 'error');
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\innova-corporativo\resources\views/tesoreria/cajas/index.blade.php ENDPATH**/ ?>